import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteTableInput, DeleteTableOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteTableCommandInput extends DeleteTableInput {}
export interface DeleteTableCommandOutput
  extends DeleteTableOutput,
    __MetadataBearer {}
declare const DeleteTableCommand_base: {
  new (
    input: DeleteTableCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DeleteTableCommandInput,
    DeleteTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteTableCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DeleteTableCommandInput,
    DeleteTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteTableCommand extends DeleteTableCommand_base {
  protected static __types: {
    api: {
      input: DeleteTableInput;
      output: DeleteTableOutput;
    };
    sdk: {
      input: DeleteTableCommandInput;
      output: DeleteTableCommandOutput;
    };
  };
}
