import { TypeRegistry } from "@smithy/core/schema";
import type { StaticErrorSchema, StaticOperationSchema, StaticStructureSchema } from "@smithy/types";
export declare var ApiGatewayManagementApiServiceException$: StaticErrorSchema;
export declare var ForbiddenException$: StaticErrorSchema;
export declare var GoneException$: StaticErrorSchema;
export declare var LimitExceededException$: StaticErrorSchema;
export declare var PayloadTooLargeException$: StaticErrorSchema;
/**
 * TypeRegistry instances containing modeled errors.
 * @internal
 *
 */
export declare const errorTypeRegistries: TypeRegistry[];
export declare var DeleteConnectionRequest$: StaticStructureSchema;
export declare var GetConnectionRequest$: StaticStructureSchema;
export declare var GetConnectionResponse$: StaticStructureSchema;
export declare var Identity$: StaticStructureSchema;
export declare var PostToConnectionRequest$: StaticStructureSchema;
export declare var DeleteConnection$: StaticOperationSchema;
export declare var GetConnection$: StaticOperationSchema;
export declare var PostToConnection$: StaticOperationSchema;
