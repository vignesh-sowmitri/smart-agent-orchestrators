import { _ep2, _mw0, command } from "../commandBuilder";
import { ListBackups$ } from "../schemas/schemas_0";
export class ListBackupsCommand extends command(_ep2, _mw0, "ListBackups", ListBackups$) {
}
