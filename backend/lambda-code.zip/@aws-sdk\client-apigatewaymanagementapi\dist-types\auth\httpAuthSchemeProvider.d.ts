import { AwsSdkSigV4AuthInputConfig, AwsSdkSigV4AuthResolvedConfig, AwsSdkSigV4PreviouslyResolved } from "@aws-sdk/core/httpAuthSchemes";
import type { HandlerExecutionContext, HttpAuthScheme, HttpAuthSchemeParameters, HttpAuthSchemeParametersProvider, HttpAuthSchemeProvider, Provider } from "@smithy/types";
import { type ApiGatewayManagementApiClientResolvedConfig } from "../ApiGatewayManagementApiClient";
/**
 * @internal
 */
export interface ApiGatewayManagementApiHttpAuthSchemeParameters extends HttpAuthSchemeParameters {
    region?: string;
}
/**
 * @internal
 */
export interface ApiGatewayManagementApiHttpAuthSchemeParametersProvider extends HttpAuthSchemeParametersProvider<ApiGatewayManagementApiClientResolvedConfig, HandlerExecutionContext, ApiGatewayManagementApiHttpAuthSchemeParameters, object> {
}
/**
 * @internal
 */
export declare const defaultApiGatewayManagementApiHttpAuthSchemeParametersProvider: (config: ApiGatewayManagementApiClientResolvedConfig, context: HandlerExecutionContext, input: object) => Promise<ApiGatewayManagementApiHttpAuthSchemeParameters>;
/**
 * @internal
 */
export interface ApiGatewayManagementApiHttpAuthSchemeProvider extends HttpAuthSchemeProvider<ApiGatewayManagementApiHttpAuthSchemeParameters> {
}
/**
 * @internal
 */
export declare const defaultApiGatewayManagementApiHttpAuthSchemeProvider: ApiGatewayManagementApiHttpAuthSchemeProvider;
/**
 * @public
 */
export interface HttpAuthSchemeInputConfig extends AwsSdkSigV4AuthInputConfig {
    /**
     * A comma-separated list of case-sensitive auth scheme names.
     * An auth scheme name is a fully qualified auth scheme ID with the namespace prefix trimmed.
     * For example, the auth scheme with ID aws.auth#sigv4 is named sigv4.
     * @public
     */
    authSchemePreference?: string[] | Provider<string[]>;
    /**
     * Configuration of HttpAuthSchemes for a client which provides default identity providers and signers per auth scheme.
     * @internal
     */
    httpAuthSchemes?: HttpAuthScheme[];
    /**
     * Configuration of an HttpAuthSchemeProvider for a client which resolves which HttpAuthScheme to use.
     * @internal
     */
    httpAuthSchemeProvider?: ApiGatewayManagementApiHttpAuthSchemeProvider;
}
/**
 * @internal
 */
export interface HttpAuthSchemeResolvedConfig extends AwsSdkSigV4AuthResolvedConfig {
    /**
     * A comma-separated list of case-sensitive auth scheme names.
     * An auth scheme name is a fully qualified auth scheme ID with the namespace prefix trimmed.
     * For example, the auth scheme with ID aws.auth#sigv4 is named sigv4.
     * @public
     */
    readonly authSchemePreference: Provider<string[]>;
    /**
     * Configuration of HttpAuthSchemes for a client which provides default identity providers and signers per auth scheme.
     * @internal
     */
    readonly httpAuthSchemes: HttpAuthScheme[];
    /**
     * Configuration of an HttpAuthSchemeProvider for a client which resolves which HttpAuthScheme to use.
     * @internal
     */
    readonly httpAuthSchemeProvider: ApiGatewayManagementApiHttpAuthSchemeProvider;
}
/**
 * @internal
 */
export declare const resolveHttpAuthSchemeConfig: <T>(config: T & HttpAuthSchemeInputConfig & AwsSdkSigV4PreviouslyResolved) => T & HttpAuthSchemeResolvedConfig;
