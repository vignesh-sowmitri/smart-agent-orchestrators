import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  ExecuteStatementInput,
  ExecuteStatementOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface ExecuteStatementCommandInput extends ExecuteStatementInput {}
export interface ExecuteStatementCommandOutput
  extends ExecuteStatementOutput,
    __MetadataBearer {}
declare const ExecuteStatementCommand_base: {
  new (
    input: ExecuteStatementCommandInput
  ): import("@smithy/core/client").CommandImpl<
    ExecuteStatementCommandInput,
    ExecuteStatementCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: ExecuteStatementCommandInput
  ): import("@smithy/core/client").CommandImpl<
    ExecuteStatementCommandInput,
    ExecuteStatementCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ExecuteStatementCommand extends ExecuteStatementCommand_base {
  protected static __types: {
    api: {
      input: ExecuteStatementInput;
      output: ExecuteStatementOutput;
    };
    sdk: {
      input: ExecuteStatementCommandInput;
      output: ExecuteStatementCommandOutput;
    };
  };
}
