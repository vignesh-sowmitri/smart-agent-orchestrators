import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CreateGlobalTableInput,
  CreateGlobalTableOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface CreateGlobalTableCommandInput extends CreateGlobalTableInput {}
export interface CreateGlobalTableCommandOutput
  extends CreateGlobalTableOutput,
    __MetadataBearer {}
declare const CreateGlobalTableCommand_base: {
  new (
    input: CreateGlobalTableCommandInput
  ): import("@smithy/core/client").CommandImpl<
    CreateGlobalTableCommandInput,
    CreateGlobalTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateGlobalTableCommandInput
  ): import("@smithy/core/client").CommandImpl<
    CreateGlobalTableCommandInput,
    CreateGlobalTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateGlobalTableCommand extends CreateGlobalTableCommand_base {
  protected static __types: {
    api: {
      input: CreateGlobalTableInput;
      output: CreateGlobalTableOutput;
    };
    sdk: {
      input: CreateGlobalTableCommandInput;
      output: CreateGlobalTableCommandOutput;
    };
  };
}
