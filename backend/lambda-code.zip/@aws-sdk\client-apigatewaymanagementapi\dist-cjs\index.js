const { awsEndpointFunctions, emitWarningIfUnsupportedVersion: emitWarningIfUnsupportedVersion$1, createDefaultUserAgentProvider, NODE_APP_ID_CONFIG_OPTIONS, getAwsRegionExtensionConfiguration, resolveAwsRegionExtensionConfiguration, resolveUserAgentConfig, resolveHostHeaderConfig, getUserAgentPlugin, getHostHeaderPlugin, getLoggerPlugin, getRecursionDetectionPlugin } = require("@aws-sdk/core/client");
const { getHttpAuthSchemeEndpointRuleSetPlugin, DefaultIdentityProviderConfig, getHttpSigningPlugin } = require("@smithy/core");
const { normalizeProvider, getSmithyContext, ServiceException, NoOpLogger, emitWarningIfUnsupportedVersion, loadConfigsForDefaultMode, getDefaultExtensionConfiguration, resolveDefaultRuntimeConfig, Client, makeBuilder, createAggregatedClient } = require("@smithy/core/client");
const { Command: $Command } = require("@smithy/core/client");
exports.$Command = $Command;
exports.__Client = Client;
const { resolveDefaultsModeConfig, loadConfig, NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS, resolveRegionConfig } = require("@smithy/core/config");
const { BinaryDecisionDiagram, EndpointCache, decideEndpoint, customEndpointFunctions, resolveEndpointConfig, getEndpointPlugin } = require("@smithy/core/endpoints");
const { parseUrl, getHttpHandlerExtensionConfiguration, resolveHttpHandlerRuntimeConfig, getContentLengthPlugin } = require("@smithy/core/protocols");
const { DEFAULT_RETRY_MODE, NODE_RETRY_MODE_CONFIG_OPTIONS, NODE_MAX_ATTEMPT_CONFIG_OPTIONS, resolveRetryConfig, getRetryPlugin } = require("@smithy/core/retry");
const { TypeRegistry, getSchemaSerdePlugin } = require("@smithy/core/schema");
const { resolveAwsSdkSigV4Config, AwsSdkSigV4Signer, NODE_AUTH_SCHEME_PREFERENCE_OPTIONS } = require("@aws-sdk/core/httpAuthSchemes");
const { defaultProvider } = require("@aws-sdk/credential-provider-node");
const { toUtf8, fromUtf8, toBase64, fromBase64, calculateBodyLength } = require("@smithy/core/serde");
const { streamCollector, NodeHttpHandler } = require("@smithy/node-http-handler");
const { AwsRestJsonProtocol } = require("@aws-sdk/core/protocols");
const { Sha256 } = require("@smithy/core/checksum");

const defaultApiGatewayManagementApiHttpAuthSchemeParametersProvider = async (config, context, input) => {
    return {
        operation: getSmithyContext(context).operation,
        region: await normalizeProvider(config.region)() || (() => {
            throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
        })(),
    };
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
    return {
        schemeId: "aws.auth#sigv4",
        signingProperties: {
            name: "execute-api",
            region: authParameters.region,
        },
        propertiesExtractor: (config, context) => ({
            signingProperties: {
                config,
                context,
            },
        }),
    };
}
const defaultApiGatewayManagementApiHttpAuthSchemeProvider = (authParameters) => {
    const options = [];
    switch (authParameters.operation) {
        default: {
            options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
        }
    }
    return options;
};
const resolveHttpAuthSchemeConfig = (config) => {
    const config_0 = resolveAwsSdkSigV4Config(config);
    return Object.assign(config_0, {
        authSchemePreference: normalizeProvider(config.authSchemePreference ?? []),
    });
};

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "execute-api",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

var version = "3.1086.0";
var packageInfo = {
	version: version};

const k = "ref";
const a = -1, b = true, c = "isSet", d = "PartitionResult", e = "booleanEquals", f = "getAttr", g = { [k]: "Endpoint" }, h = { [k]: d }, i = {}, j = [{ [k]: "Region" }];
const _data = {
    conditions: [
        [c, [g]],
        [c, j],
        ["aws.partition", j, d],
        [e, [{ [k]: "UseFIPS" }, b]],
        [e, [{ [k]: "UseDualStack" }, b]],
        [e, [{ fn: f, argv: [h, "supportsDualStack"] }, b]],
        [e, [{ fn: f, argv: [h, "supportsFIPS"] }, b]]
    ],
    results: [
        [a],
        [a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
        [a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
        [g, i],
        ["https://execute-api-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
        ["https://execute-api-fips.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "FIPS is enabled but this partition does not support FIPS"],
        ["https://execute-api.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "DualStack is enabled but this partition does not support DualStack"],
        ["https://execute-api.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "Invalid Configuration: Missing Region"]
    ]
};
const root = 2;
const r = 100_000_000;
const nodes = new Int32Array([
    -1, 1, -1,
    0, 12, 3,
    1, 4, r + 11,
    2, 5, r + 11,
    3, 8, 6,
    4, 7, r + 10,
    5, r + 8, r + 9,
    4, 10, 9,
    6, r + 6, r + 7,
    5, 11, r + 5,
    6, r + 4, r + 5,
    3, r + 1, 13,
    4, r + 2, r + 3,
]);
const bdd = BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);

const cache = new EndpointCache({
    size: 50,
    params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
});
const defaultEndpointResolver = (endpointParams, context = {}) => {
    return cache.get(endpointParams, () => decideEndpoint(bdd, {
        endpointParams: endpointParams,
        logger: context.logger,
    }));
};
customEndpointFunctions.aws = awsEndpointFunctions;

class ApiGatewayManagementApiServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, ApiGatewayManagementApiServiceException.prototype);
    }
}

class ForbiddenException extends ApiGatewayManagementApiServiceException {
    name = "ForbiddenException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ForbiddenException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ForbiddenException.prototype);
    }
}
class GoneException extends ApiGatewayManagementApiServiceException {
    name = "GoneException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GoneException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GoneException.prototype);
    }
}
class LimitExceededException extends ApiGatewayManagementApiServiceException {
    name = "LimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "LimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, LimitExceededException.prototype);
    }
}
class PayloadTooLargeException extends ApiGatewayManagementApiServiceException {
    name = "PayloadTooLargeException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "PayloadTooLargeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PayloadTooLargeException.prototype);
        this.Message = opts.Message;
    }
}

const _CA = "ConnectedAt";
const _CI = "ConnectionId";
const _D = "Data";
const _DC = "DeleteConnection";
const _DCR = "DeleteConnectionRequest";
const _FE = "ForbiddenException";
const _GC = "GetConnection";
const _GCR = "GetConnectionRequest";
const _GCRe = "GetConnectionResponse";
const _GE = "GoneException";
const _I = "Identity";
const _LAA = "LastActiveAt";
const _LEE = "LimitExceededException";
const _M = "Message";
const _PTC = "PostToConnection";
const _PTCR = "PostToConnectionRequest";
const _PTLE = "PayloadTooLargeException";
const _SI = "SourceIp";
const _UA = "UserAgent";
const _c = "client";
const _cA = "connectedAt";
const _e = "error";
const _h = "http";
const _hE = "httpError";
const _i = "identity";
const _jN = "jsonName";
const _lAA = "lastActiveAt";
const _m = "message";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.apigatewaymanagementapi";
const _sI = "sourceIp";
const _uA = "userAgent";
const n0 = "com.amazonaws.apigatewaymanagementapi";
const _s_registry = TypeRegistry.for(_s);
var ApiGatewayManagementApiServiceException$ = [-3, _s, "ApiGatewayManagementApiServiceException", 0, [], []];
_s_registry.registerError(ApiGatewayManagementApiServiceException$, ApiGatewayManagementApiServiceException);
const n0_registry = TypeRegistry.for(n0);
var ForbiddenException$ = [-3, n0, _FE,
    { [_e]: _c, [_hE]: 403 },
    [],
    []
];
n0_registry.registerError(ForbiddenException$, ForbiddenException);
var GoneException$ = [-3, n0, _GE,
    { [_e]: _c, [_hE]: 410 },
    [],
    []
];
n0_registry.registerError(GoneException$, GoneException);
var LimitExceededException$ = [-3, n0, _LEE,
    { [_e]: _c, [_hE]: 429 },
    [],
    []
];
n0_registry.registerError(LimitExceededException$, LimitExceededException);
var PayloadTooLargeException$ = [-3, n0, _PTLE,
    { [_e]: _c, [_hE]: 413 },
    [_M],
    [[0, { [_jN]: _m }]]
];
n0_registry.registerError(PayloadTooLargeException$, PayloadTooLargeException);
const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var DeleteConnectionRequest$ = [3, n0, _DCR,
    0,
    [_CI],
    [[0, 1]], 1
];
var GetConnectionRequest$ = [3, n0, _GCR,
    0,
    [_CI],
    [[0, 1]], 1
];
var GetConnectionResponse$ = [3, n0, _GCRe,
    0,
    [_CA, _I, _LAA],
    [[5, { [_jN]: _cA }], [() => Identity$, { [_jN]: _i }], [5, { [_jN]: _lAA }]]
];
var Identity$ = [3, n0, _I,
    0,
    [_SI, _UA],
    [[0, { [_jN]: _sI }], [0, { [_jN]: _uA }]], 2
];
var PostToConnectionRequest$ = [3, n0, _PTCR,
    0,
    [_D, _CI],
    [[21, 16], [0, 1]], 2
];
var __Unit = "unit";
var DeleteConnection$ = [9, n0, _DC,
    { [_h]: ["DELETE", "/@connections/{ConnectionId}", 204] }, () => DeleteConnectionRequest$, () => __Unit
];
var GetConnection$ = [9, n0, _GC,
    { [_h]: ["GET", "/@connections/{ConnectionId}", 200] }, () => GetConnectionRequest$, () => GetConnectionResponse$
];
var PostToConnection$ = [9, n0, _PTC,
    { [_h]: ["POST", "/@connections/{ConnectionId}", 200] }, () => PostToConnectionRequest$, () => __Unit
];

const getRuntimeConfig$1 = (config) => {
    return {
        apiVersion: "2018-11-29",
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        disableHostPrefix: config?.disableHostPrefix ?? false,
        endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
        extensions: config?.extensions ?? [],
        httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultApiGatewayManagementApiHttpAuthSchemeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new AwsSdkSigV4Signer(),
            },
        ],
        logger: config?.logger ?? new NoOpLogger(),
        protocol: config?.protocol ?? AwsRestJsonProtocol,
        protocolSettings: config?.protocolSettings ?? {
            defaultNamespace: "com.amazonaws.apigatewaymanagementapi",
            errorTypeRegistries,
            version: "2018-11-29",
            serviceTarget: "ApiGatewayManagementApi",
        },
        serviceId: config?.serviceId ?? "ApiGatewayManagementApi",
        sha256: config?.sha256 ?? Sha256,
        urlParser: config?.urlParser ?? parseUrl,
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

const getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = getRuntimeConfig$1(config);
    emitWarningIfUnsupportedVersion$1(process.version);
    const loaderConfig = {
        profile: config?.profile,
        logger: clientSharedValues.logger,
    };
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        authSchemePreference: config?.authSchemePreference ?? loadConfig(NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
        defaultUserAgentProvider: config?.defaultUserAgentProvider ?? createDefaultUserAgentProvider({ serviceId: clientSharedValues.serviceId, clientVersion: packageInfo.version }),
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, { ...NODE_REGION_CONFIG_FILE_OPTIONS, ...loaderConfig }),
        requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }, config),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        userAgentAppId: config?.userAgentAppId ?? loadConfig(NODE_APP_ID_CONFIG_OPTIONS, loaderConfig),
    };
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(getAwsRegionExtensionConfiguration(runtimeConfig), getDefaultExtensionConfiguration(runtimeConfig), getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, resolveAwsRegionExtensionConfiguration(extensionConfiguration), resolveDefaultRuntimeConfig(extensionConfiguration), resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class ApiGatewayManagementApiClient extends Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = resolveUserAgentConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveRegionConfig(_config_3);
        const _config_5 = resolveHostHeaderConfig(_config_4);
        const _config_6 = resolveEndpointConfig(_config_5);
        const _config_7 = resolveHttpAuthSchemeConfig(_config_6);
        const _config_8 = resolveRuntimeExtensions(_config_7, configuration?.extensions || []);
        this.config = _config_8;
        this.middlewareStack.use(getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: defaultApiGatewayManagementApiHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

const command = makeBuilder(commonParams, "ApiGatewayManagementApi", "ApiGatewayManagementApiClient", getEndpointPlugin);
const _ep0 = {};
const _mw0 = (Command, cs, config, o) => [];

class DeleteConnectionCommand extends command(_ep0, _mw0, "DeleteConnection", DeleteConnection$) {
}

class GetConnectionCommand extends command(_ep0, _mw0, "GetConnection", GetConnection$) {
}

class PostToConnectionCommand extends command(_ep0, _mw0, "PostToConnection", PostToConnection$) {
}

const commands = {
    DeleteConnectionCommand,
    GetConnectionCommand,
    PostToConnectionCommand,
};
class ApiGatewayManagementApi extends ApiGatewayManagementApiClient {
}
createAggregatedClient(commands, ApiGatewayManagementApi);

exports.ApiGatewayManagementApi = ApiGatewayManagementApi;
exports.ApiGatewayManagementApiClient = ApiGatewayManagementApiClient;
exports.ApiGatewayManagementApiServiceException = ApiGatewayManagementApiServiceException;
exports.ApiGatewayManagementApiServiceException$ = ApiGatewayManagementApiServiceException$;
exports.DeleteConnection$ = DeleteConnection$;
exports.DeleteConnectionCommand = DeleteConnectionCommand;
exports.DeleteConnectionRequest$ = DeleteConnectionRequest$;
exports.ForbiddenException = ForbiddenException;
exports.ForbiddenException$ = ForbiddenException$;
exports.GetConnection$ = GetConnection$;
exports.GetConnectionCommand = GetConnectionCommand;
exports.GetConnectionRequest$ = GetConnectionRequest$;
exports.GetConnectionResponse$ = GetConnectionResponse$;
exports.GoneException = GoneException;
exports.GoneException$ = GoneException$;
exports.Identity$ = Identity$;
exports.LimitExceededException = LimitExceededException;
exports.LimitExceededException$ = LimitExceededException$;
exports.PayloadTooLargeException = PayloadTooLargeException;
exports.PayloadTooLargeException$ = PayloadTooLargeException$;
exports.PostToConnection$ = PostToConnection$;
exports.PostToConnectionCommand = PostToConnectionCommand;
exports.PostToConnectionRequest$ = PostToConnectionRequest$;
exports.errorTypeRegistries = errorTypeRegistries;
