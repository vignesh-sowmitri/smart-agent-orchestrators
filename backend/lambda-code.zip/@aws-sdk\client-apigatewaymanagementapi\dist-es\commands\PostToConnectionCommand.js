import { _ep0, _mw0, command } from "../commandBuilder";
import { PostToConnection$ } from "../schemas/schemas_0";
export class PostToConnectionCommand extends command(_ep0, _mw0, "PostToConnection", PostToConnection$) {
}
