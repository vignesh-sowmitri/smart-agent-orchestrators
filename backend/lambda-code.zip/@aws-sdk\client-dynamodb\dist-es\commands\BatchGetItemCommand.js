import { _ep1, _mw0, command } from "../commandBuilder";
import { BatchGetItem$ } from "../schemas/schemas_0";
export class BatchGetItemCommand extends command(_ep1, _mw0, "BatchGetItem", BatchGetItem$) {
}
