import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  ListTagsOfResourceInput,
  ListTagsOfResourceOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface ListTagsOfResourceCommandInput
  extends ListTagsOfResourceInput {}
export interface ListTagsOfResourceCommandOutput
  extends ListTagsOfResourceOutput,
    __MetadataBearer {}
declare const ListTagsOfResourceCommand_base: {
  new (
    input: ListTagsOfResourceCommandInput
  ): import("@smithy/core/client").CommandImpl<
    ListTagsOfResourceCommandInput,
    ListTagsOfResourceCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: ListTagsOfResourceCommandInput
  ): import("@smithy/core/client").CommandImpl<
    ListTagsOfResourceCommandInput,
    ListTagsOfResourceCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListTagsOfResourceCommand extends ListTagsOfResourceCommand_base {
  protected static __types: {
    api: {
      input: ListTagsOfResourceInput;
      output: ListTagsOfResourceOutput;
    };
    sdk: {
      input: ListTagsOfResourceCommandInput;
      output: ListTagsOfResourceCommandOutput;
    };
  };
}
