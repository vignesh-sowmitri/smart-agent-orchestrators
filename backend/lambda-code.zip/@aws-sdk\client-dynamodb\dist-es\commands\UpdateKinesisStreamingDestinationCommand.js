import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateKinesisStreamingDestination$ } from "../schemas/schemas_0";
export class UpdateKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "UpdateKinesisStreamingDestination", UpdateKinesisStreamingDestination$) {
}
