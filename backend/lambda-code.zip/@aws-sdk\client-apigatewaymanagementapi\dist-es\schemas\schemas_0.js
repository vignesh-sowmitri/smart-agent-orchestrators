const _CA = "ConnectedAt";
const _CI = "ConnectionId";
const _D = "Data";
const _DC = "DeleteConnection";
const _DCR = "DeleteConnectionRequest";
const _FE = "ForbiddenException";
const _GC = "GetConnection";
const _GCR = "GetConnectionRequest";
const _GCRe = "GetConnectionResponse";
const _GE = "GoneException";
const _I = "Identity";
const _LAA = "LastActiveAt";
const _LEE = "LimitExceededException";
const _M = "Message";
const _PTC = "PostToConnection";
const _PTCR = "PostToConnectionRequest";
const _PTLE = "PayloadTooLargeException";
const _SI = "SourceIp";
const _UA = "UserAgent";
const _c = "client";
const _cA = "connectedAt";
const _e = "error";
const _h = "http";
const _hE = "httpError";
const _i = "identity";
const _jN = "jsonName";
const _lAA = "lastActiveAt";
const _m = "message";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.apigatewaymanagementapi";
const _sI = "sourceIp";
const _uA = "userAgent";
const n0 = "com.amazonaws.apigatewaymanagementapi";
import { TypeRegistry } from "@smithy/core/schema";
import { ApiGatewayManagementApiServiceException } from "../models/ApiGatewayManagementApiServiceException";
import { ForbiddenException, GoneException, LimitExceededException, PayloadTooLargeException } from "../models/errors";
const _s_registry = TypeRegistry.for(_s);
export var ApiGatewayManagementApiServiceException$ = [-3, _s, "ApiGatewayManagementApiServiceException", 0, [], []];
_s_registry.registerError(ApiGatewayManagementApiServiceException$, ApiGatewayManagementApiServiceException);
const n0_registry = TypeRegistry.for(n0);
export var ForbiddenException$ = [-3, n0, _FE,
    { [_e]: _c, [_hE]: 403 },
    [],
    []
];
n0_registry.registerError(ForbiddenException$, ForbiddenException);
export var GoneException$ = [-3, n0, _GE,
    { [_e]: _c, [_hE]: 410 },
    [],
    []
];
n0_registry.registerError(GoneException$, GoneException);
export var LimitExceededException$ = [-3, n0, _LEE,
    { [_e]: _c, [_hE]: 429 },
    [],
    []
];
n0_registry.registerError(LimitExceededException$, LimitExceededException);
export var PayloadTooLargeException$ = [-3, n0, _PTLE,
    { [_e]: _c, [_hE]: 413 },
    [_M],
    [[0, { [_jN]: _m }]]
];
n0_registry.registerError(PayloadTooLargeException$, PayloadTooLargeException);
export const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
export var DeleteConnectionRequest$ = [3, n0, _DCR,
    0,
    [_CI],
    [[0, 1]], 1
];
export var GetConnectionRequest$ = [3, n0, _GCR,
    0,
    [_CI],
    [[0, 1]], 1
];
export var GetConnectionResponse$ = [3, n0, _GCRe,
    0,
    [_CA, _I, _LAA],
    [[5, { [_jN]: _cA }], [() => Identity$, { [_jN]: _i }], [5, { [_jN]: _lAA }]]
];
export var Identity$ = [3, n0, _I,
    0,
    [_SI, _UA],
    [[0, { [_jN]: _sI }], [0, { [_jN]: _uA }]], 2
];
export var PostToConnectionRequest$ = [3, n0, _PTCR,
    0,
    [_D, _CI],
    [[21, 16], [0, 1]], 2
];
var __Unit = "unit";
export var DeleteConnection$ = [9, n0, _DC,
    { [_h]: ["DELETE", "/@connections/{ConnectionId}", 204] }, () => DeleteConnectionRequest$, () => __Unit
];
export var GetConnection$ = [9, n0, _GC,
    { [_h]: ["GET", "/@connections/{ConnectionId}", 200] }, () => GetConnectionRequest$, () => GetConnectionResponse$
];
export var PostToConnection$ = [9, n0, _PTC,
    { [_h]: ["POST", "/@connections/{ConnectionId}", 200] }, () => PostToConnectionRequest$, () => __Unit
];
