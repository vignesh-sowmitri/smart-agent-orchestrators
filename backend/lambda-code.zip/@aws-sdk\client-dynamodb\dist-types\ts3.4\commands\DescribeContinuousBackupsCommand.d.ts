import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeContinuousBackupsInput,
  DescribeContinuousBackupsOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeContinuousBackupsCommandInput
  extends DescribeContinuousBackupsInput {}
export interface DescribeContinuousBackupsCommandOutput
  extends DescribeContinuousBackupsOutput,
    __MetadataBearer {}
declare const DescribeContinuousBackupsCommand_base: {
  new (
    input: DescribeContinuousBackupsCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DescribeContinuousBackupsCommandInput,
    DescribeContinuousBackupsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeContinuousBackupsCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DescribeContinuousBackupsCommandInput,
    DescribeContinuousBackupsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeContinuousBackupsCommand extends DescribeContinuousBackupsCommand_base {
  protected static __types: {
    api: {
      input: DescribeContinuousBackupsInput;
      output: DescribeContinuousBackupsOutput;
    };
    sdk: {
      input: DescribeContinuousBackupsCommandInput;
      output: DescribeContinuousBackupsCommandOutput;
    };
  };
}
