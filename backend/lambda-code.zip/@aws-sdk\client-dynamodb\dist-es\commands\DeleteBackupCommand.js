import { _ep4, _mw0, command } from "../commandBuilder";
import { DeleteBackup$ } from "../schemas/schemas_0";
export class DeleteBackupCommand extends command(_ep4, _mw0, "DeleteBackup", DeleteBackup$) {
}
