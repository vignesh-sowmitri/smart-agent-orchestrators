import { _ep2, _mw0, command } from "../commandBuilder";
import { CreateTable$ } from "../schemas/schemas_0";
export class CreateTableCommand extends command(_ep2, _mw0, "CreateTable", CreateTable$) {
}
