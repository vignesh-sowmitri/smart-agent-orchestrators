/**
 * <p>Describes the API operations for running inference using Amazon Bedrock models.</p>
 *
 * @packageDocumentation
 */
export * from "./BedrockRuntimeClient";
export * from "./BedrockRuntime";
export type { ClientInputEndpointParameters } from "./endpoint/EndpointParameters";
export type { RuntimeExtension } from "./runtimeExtensions";
export type { BedrockRuntimeExtensionConfiguration } from "./extensionConfiguration";
export * from "./commands";
export { Command as $Command } from "@smithy/core/client";
export * from "./schemas/schemas_0";
export * from "./pagination";
export * from "./models/enums";
export * from "./models/errors";
export * from "./models/models_0";
export { BedrockRuntimeServiceException } from "./models/BedrockRuntimeServiceException";
