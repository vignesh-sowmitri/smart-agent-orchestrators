import {
  BlobPayloadInputTypes,
  MetadataBearer as __MetadataBearer,
} from "@smithy/types";
import { PostToConnectionRequest } from "../models/models_0";
export { __MetadataBearer };
export type PostToConnectionCommandInputType = Pick<
  PostToConnectionRequest,
  Exclude<keyof PostToConnectionRequest, "Data">
> & {
  Data: BlobPayloadInputTypes;
};
export interface PostToConnectionCommandInput
  extends PostToConnectionCommandInputType {}
export interface PostToConnectionCommandOutput extends __MetadataBearer {}
declare const PostToConnectionCommand_base: {
  new (
    input: PostToConnectionCommandInput
  ): import("@smithy/core/client").CommandImpl<
    PostToConnectionCommandInput,
    PostToConnectionCommandOutput,
    import("..").ApiGatewayManagementApiClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: PostToConnectionCommandInput
  ): import("@smithy/core/client").CommandImpl<
    PostToConnectionCommandInput,
    PostToConnectionCommandOutput,
    import("..").ApiGatewayManagementApiClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class PostToConnectionCommand extends PostToConnectionCommand_base {
  protected static __types: {
    api: {
      input: PostToConnectionRequest;
      output: {};
    };
    sdk: {
      input: PostToConnectionCommandInput;
      output: PostToConnectionCommandOutput;
    };
  };
}
