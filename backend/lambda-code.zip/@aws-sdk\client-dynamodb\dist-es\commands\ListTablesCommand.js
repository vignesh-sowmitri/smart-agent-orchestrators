import { _ep0, _mw0, command } from "../commandBuilder";
import { ListTables$ } from "../schemas/schemas_0";
export class ListTablesCommand extends command(_ep0, _mw0, "ListTables", ListTables$) {
}
