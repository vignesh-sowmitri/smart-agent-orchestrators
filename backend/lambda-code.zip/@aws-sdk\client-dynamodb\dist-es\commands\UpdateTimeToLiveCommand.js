import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateTimeToLive$ } from "../schemas/schemas_0";
export class UpdateTimeToLiveCommand extends command(_ep2, _mw0, "UpdateTimeToLive", UpdateTimeToLive$) {
}
