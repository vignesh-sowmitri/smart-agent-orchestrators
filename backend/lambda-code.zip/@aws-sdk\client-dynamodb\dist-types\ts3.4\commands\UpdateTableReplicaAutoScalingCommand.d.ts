import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  UpdateTableReplicaAutoScalingInput,
  UpdateTableReplicaAutoScalingOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface UpdateTableReplicaAutoScalingCommandInput
  extends UpdateTableReplicaAutoScalingInput {}
export interface UpdateTableReplicaAutoScalingCommandOutput
  extends UpdateTableReplicaAutoScalingOutput,
    __MetadataBearer {}
declare const UpdateTableReplicaAutoScalingCommand_base: {
  new (
    input: UpdateTableReplicaAutoScalingCommandInput
  ): import("@smithy/core/client").CommandImpl<
    UpdateTableReplicaAutoScalingCommandInput,
    UpdateTableReplicaAutoScalingCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateTableReplicaAutoScalingCommandInput
  ): import("@smithy/core/client").CommandImpl<
    UpdateTableReplicaAutoScalingCommandInput,
    UpdateTableReplicaAutoScalingCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateTableReplicaAutoScalingCommand extends UpdateTableReplicaAutoScalingCommand_base {
  protected static __types: {
    api: {
      input: UpdateTableReplicaAutoScalingInput;
      output: UpdateTableReplicaAutoScalingOutput;
    };
    sdk: {
      input: UpdateTableReplicaAutoScalingCommandInput;
      output: UpdateTableReplicaAutoScalingCommandOutput;
    };
  };
}
