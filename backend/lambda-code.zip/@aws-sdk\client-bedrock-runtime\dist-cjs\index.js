const { awsEndpointFunctions, emitWarningIfUnsupportedVersion: emitWarningIfUnsupportedVersion$1, createDefaultUserAgentProvider, NODE_APP_ID_CONFIG_OPTIONS, getAwsRegionExtensionConfiguration, resolveAwsRegionExtensionConfiguration, resolveUserAgentConfig, resolveHostHeaderConfig, getUserAgentPlugin, getHostHeaderPlugin, getLoggerPlugin, getRecursionDetectionPlugin } = require("@aws-sdk/core/client");
const { resolveEventStreamConfig, getEventStreamPlugin } = require("@aws-sdk/middleware-eventstream");
const { resolveWebSocketConfig, getWebSocketPlugin } = require("@aws-sdk/middleware-websocket");
const { memoizeIdentityProvider, isIdentityExpired, doesIdentityRequireRefresh, HttpBearerAuthSigner, getHttpAuthSchemeEndpointRuleSetPlugin, DefaultIdentityProviderConfig, getHttpSigningPlugin, createPaginator } = require("@smithy/core");
const { normalizeProvider, getSmithyContext, ServiceException, NoOpLogger, emitWarningIfUnsupportedVersion, loadConfigsForDefaultMode, getDefaultExtensionConfiguration, resolveDefaultRuntimeConfig, Client, makeBuilder, createAggregatedClient } = require("@smithy/core/client");
const { Command: $Command } = require("@smithy/core/client");
exports.$Command = $Command;
exports.__Client = Client;
const { resolveDefaultsModeConfig, loadConfig, NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS, resolveRegionConfig } = require("@smithy/core/config");
const { BinaryDecisionDiagram, EndpointCache, decideEndpoint, customEndpointFunctions, resolveEndpointConfig, getEndpointPlugin } = require("@smithy/core/endpoints");
const { eventStreamSerdeProvider, resolveEventStreamSerdeConfig } = require("@smithy/core/event-streams");
const { parseUrl, getHttpHandlerExtensionConfiguration, resolveHttpHandlerRuntimeConfig, getContentLengthPlugin } = require("@smithy/core/protocols");
const { DEFAULT_RETRY_MODE, NODE_RETRY_MODE_CONFIG_OPTIONS, NODE_MAX_ATTEMPT_CONFIG_OPTIONS, resolveRetryConfig, getRetryPlugin } = require("@smithy/core/retry");
const { TypeRegistry, getSchemaSerdePlugin } = require("@smithy/core/schema");
const { resolveAwsSdkSigV4Config, AwsSdkSigV4Signer, NODE_AUTH_SCHEME_PREFERENCE_OPTIONS } = require("@aws-sdk/core/httpAuthSchemes");
const { defaultProvider } = require("@aws-sdk/credential-provider-node");
const { eventStreamPayloadHandlerProvider } = require("@aws-sdk/eventstream-handler-node");
const { fromEnvSigningName, nodeProvider } = require("@aws-sdk/token-providers");
const { toUtf8, fromUtf8, toBase64, fromBase64, calculateBodyLength } = require("@smithy/core/serde");
const { streamCollector, NodeHttp2Handler } = require("@smithy/node-http-handler");
const { AwsRestJsonProtocol } = require("@aws-sdk/core/protocols");
const { Sha256 } = require("@smithy/core/checksum");

const defaultBedrockRuntimeHttpAuthSchemeParametersProvider = async (config, context, input) => {
    return {
        operation: getSmithyContext(context).operation,
        region: await normalizeProvider(config.region)() || (() => {
            throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
        })(),
    };
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
    return {
        schemeId: "aws.auth#sigv4",
        signingProperties: {
            name: "bedrock",
            region: authParameters.region,
        },
        propertiesExtractor: (config, context) => ({
            signingProperties: {
                config,
                context,
            },
        }),
    };
}
function createSmithyApiHttpBearerAuthHttpAuthOption(authParameters) {
    return {
        schemeId: "smithy.api#httpBearerAuth",
        propertiesExtractor: ({ profile, filepath, configFilepath, ignoreCache, }, context) => ({
            identityProperties: {
                profile,
                filepath,
                configFilepath,
                ignoreCache,
            },
        }),
    };
}
const defaultBedrockRuntimeHttpAuthSchemeProvider = (authParameters) => {
    const options = [];
    switch (authParameters.operation) {
        default: {
            options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
            options.push(createSmithyApiHttpBearerAuthHttpAuthOption());
        }
    }
    return options;
};
const resolveHttpAuthSchemeConfig = (config) => {
    const token = memoizeIdentityProvider(config.token, isIdentityExpired, doesIdentityRequireRefresh);
    const config_0 = resolveAwsSdkSigV4Config(config);
    return Object.assign(config_0, {
        authSchemePreference: normalizeProvider(config.authSchemePreference ?? []),
        token,
    });
};

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "bedrock",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

var version = "3.1086.0";
var packageInfo = {
	version: version};

const k = "ref";
const a = -1, b = true, c = "isSet", d = "PartitionResult", e = "booleanEquals", f = "getAttr", g = { [k]: "Endpoint" }, h = { [k]: d }, i = {}, j = [{ [k]: "Region" }];
const _data = {
    conditions: [
        [c, [g]],
        [c, j],
        ["aws.partition", j, d],
        [e, [{ [k]: "UseFIPS" }, b]],
        [e, [{ [k]: "UseDualStack" }, b]],
        [e, [{ fn: f, argv: [h, "supportsDualStack"] }, b]],
        [e, [{ fn: f, argv: [h, "supportsFIPS"] }, b]]
    ],
    results: [
        [a],
        [a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
        [a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
        [g, i],
        ["https://bedrock-runtime-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
        ["https://bedrock-runtime-fips.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "FIPS is enabled but this partition does not support FIPS"],
        ["https://bedrock-runtime.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "DualStack is enabled but this partition does not support DualStack"],
        ["https://bedrock-runtime.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "Invalid Configuration: Missing Region"]
    ]
};
const root = 2;
const r = 100_000_000;
const nodes = new Int32Array([
    -1, 1, -1,
    0, 12, 3,
    1, 4, r + 11,
    2, 5, r + 11,
    3, 8, 6,
    4, 7, r + 10,
    5, r + 8, r + 9,
    4, 10, 9,
    6, r + 6, r + 7,
    5, 11, r + 5,
    6, r + 4, r + 5,
    3, r + 1, 13,
    4, r + 2, r + 3,
]);
const bdd = BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);

const cache = new EndpointCache({
    size: 50,
    params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
});
const defaultEndpointResolver = (endpointParams, context = {}) => {
    return cache.get(endpointParams, () => decideEndpoint(bdd, {
        endpointParams: endpointParams,
        logger: context.logger,
    }));
};
customEndpointFunctions.aws = awsEndpointFunctions;

class BedrockRuntimeServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, BedrockRuntimeServiceException.prototype);
    }
}

class AccessDeniedException extends BedrockRuntimeServiceException {
    name = "AccessDeniedException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
    }
}
class InternalServerException extends BedrockRuntimeServiceException {
    name = "InternalServerException";
    $fault = "server";
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerException.prototype);
    }
}
class ThrottlingException extends BedrockRuntimeServiceException {
    name = "ThrottlingException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
    }
}
class ValidationException extends BedrockRuntimeServiceException {
    name = "ValidationException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
    }
}
class ConflictException extends BedrockRuntimeServiceException {
    name = "ConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConflictException.prototype);
    }
}
class ResourceNotFoundException extends BedrockRuntimeServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
class ServiceQuotaExceededException extends BedrockRuntimeServiceException {
    name = "ServiceQuotaExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ServiceQuotaExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
    }
}
class ServiceUnavailableException extends BedrockRuntimeServiceException {
    name = "ServiceUnavailableException";
    $fault = "server";
    constructor(opts) {
        super({
            name: "ServiceUnavailableException",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceUnavailableException.prototype);
    }
}
class ModelErrorException extends BedrockRuntimeServiceException {
    name = "ModelErrorException";
    $fault = "client";
    originalStatusCode;
    resourceName;
    constructor(opts) {
        super({
            name: "ModelErrorException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ModelErrorException.prototype);
        this.originalStatusCode = opts.originalStatusCode;
        this.resourceName = opts.resourceName;
    }
}
class ModelNotReadyException extends BedrockRuntimeServiceException {
    name = "ModelNotReadyException";
    $fault = "client";
    $retryable = {};
    constructor(opts) {
        super({
            name: "ModelNotReadyException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ModelNotReadyException.prototype);
    }
}
class ModelTimeoutException extends BedrockRuntimeServiceException {
    name = "ModelTimeoutException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ModelTimeoutException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ModelTimeoutException.prototype);
    }
}
class ModelStreamErrorException extends BedrockRuntimeServiceException {
    name = "ModelStreamErrorException";
    $fault = "client";
    originalStatusCode;
    originalMessage;
    constructor(opts) {
        super({
            name: "ModelStreamErrorException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ModelStreamErrorException.prototype);
        this.originalStatusCode = opts.originalStatusCode;
        this.originalMessage = opts.originalMessage;
    }
}

const _A = "Accept";
const _AB = "AudioBlock";
const _ADE = "AccessDeniedException";
const _AG = "ApplyGuardrail";
const _AGD = "AppliedGuardrailDetails";
const _AGR = "ApplyGuardrailRequest";
const _AGRp = "ApplyGuardrailResponse";
const _AIM = "AsyncInvokeMessage";
const _AIODC = "AsyncInvokeOutputDataConfig";
const _AIS = "AsyncInvokeSummary";
const _AISODC = "AsyncInvokeS3OutputDataConfig";
const _AISs = "AsyncInvokeSummaries";
const _AS = "AudioSource";
const _ATC = "AnyToolChoice";
const _ATCu = "AutoToolChoice";
const _B = "Body";
const _BIPP = "BidirectionalInputPayloadPart";
const _BOPP = "BidirectionalOutputPayloadPart";
const _C = "Citation";
const _CB = "ContentBlocks";
const _CBD = "ContentBlockDelta";
const _CBDE = "ContentBlockDeltaEvent";
const _CBS = "ContentBlockStart";
const _CBSE = "ContentBlockStartEvent";
const _CBSEo = "ContentBlockStopEvent";
const _CBo = "ContentBlock";
const _CC = "CitationsConfig";
const _CCB = "CitationsContentBlock";
const _CD = "CacheDetail";
const _CDL = "CacheDetailsList";
const _CDi = "CitationsDelta";
const _CE = "ConflictException";
const _CGC = "CitationGeneratedContent";
const _CGCL = "CitationGeneratedContentList";
const _CL = "CitationLocation";
const _CM = "ConverseMetrics";
const _CO = "ConverseOutput";
const _CPB = "CachePointBlock";
const _CR = "ConverseRequest";
const _CRo = "ConverseResponse";
const _CS = "ConverseStream";
const _CSC = "CitationSourceContent";
const _CSCD = "CitationSourceContentDelta";
const _CSCL = "CitationSourceContentList";
const _CSCLD = "CitationSourceContentListDelta";
const _CSM = "ConverseStreamMetrics";
const _CSME = "ConverseStreamMetadataEvent";
const _CSO = "ConverseStreamOutput";
const _CSR = "ConverseStreamRequest";
const _CSRo = "ConverseStreamResponse";
const _CST = "ConverseStreamTrace";
const _CT = "ConverseTrace";
const _CTI = "CountTokensInput";
const _CTR = "ConverseTokensRequest";
const _CTRo = "CountTokensRequest";
const _CTRou = "CountTokensResponse";
const _CT_ = "Content-Type";
const _CTo = "CountTokens";
const _Ci = "Citations";
const _Co = "Converse";
const _DB = "DocumentBlock";
const _DCB = "DocumentContentBlocks";
const _DCBo = "DocumentContentBlock";
const _DCL = "DocumentCharLocation";
const _DCLo = "DocumentChunkLocation";
const _DPL = "DocumentPageLocation";
const _DS = "DocumentSource";
const _EB = "ErrorBlock";
const _GA = "GuardrailAssessment";
const _GAI = "GetAsyncInvoke";
const _GAIR = "GetAsyncInvokeRequest";
const _GAIRe = "GetAsyncInvokeResponse";
const _GAL = "GuardrailAssessmentList";
const _GALM = "GuardrailAssessmentListMap";
const _GAM = "GuardrailAssessmentMap";
const _GARDSL = "GuardrailAutomatedReasoningDifferenceScenarioList";
const _GARF = "GuardrailAutomatedReasoningFinding";
const _GARFL = "GuardrailAutomatedReasoningFindingList";
const _GARIF = "GuardrailAutomatedReasoningImpossibleFinding";
const _GARIFu = "GuardrailAutomatedReasoningInvalidFinding";
const _GARITR = "GuardrailAutomatedReasoningInputTextReference";
const _GARITRL = "GuardrailAutomatedReasoningInputTextReferenceList";
const _GARLW = "GuardrailAutomatedReasoningLogicWarning";
const _GARNTF = "GuardrailAutomatedReasoningNoTranslationsFinding";
const _GARPA = "GuardrailAutomatedReasoningPolicyAssessment";
const _GARR = "GuardrailAutomatedReasoningRule";
const _GARRL = "GuardrailAutomatedReasoningRuleList";
const _GARS = "GuardrailAutomatedReasoningScenario";
const _GARSF = "GuardrailAutomatedReasoningSatisfiableFinding";
const _GARSL = "GuardrailAutomatedReasoningStatementList";
const _GARSLC = "GuardrailAutomatedReasoningStatementLogicContent";
const _GARSNLC = "GuardrailAutomatedReasoningStatementNaturalLanguageContent";
const _GARSu = "GuardrailAutomatedReasoningStatement";
const _GART = "GuardrailAutomatedReasoningTranslation";
const _GARTAF = "GuardrailAutomatedReasoningTranslationAmbiguousFinding";
const _GARTCF = "GuardrailAutomatedReasoningTooComplexFinding";
const _GARTL = "GuardrailAutomatedReasoningTranslationList";
const _GARTO = "GuardrailAutomatedReasoningTranslationOption";
const _GARTOL = "GuardrailAutomatedReasoningTranslationOptionList";
const _GARVF = "GuardrailAutomatedReasoningValidFinding";
const _GC = "GuardrailConfiguration";
const _GCB = "GuardrailContentBlock";
const _GCBL = "GuardrailContentBlockList";
const _GCC = "GuardrailChecksConfig";
const _GCCB = "GuardrailChecksContentBlock";
const _GCCBL = "GuardrailChecksContentBlockList";
const _GCCBu = "GuardrailConverseContentBlock";
const _GCCFC = "GuardrailChecksContentFilterConfig";
const _GCCFCC = "GuardrailChecksContentFilterCategoryConfig";
const _GCCFCCL = "GuardrailChecksContentFilterCategoryConfigList";
const _GCCFR = "GuardrailChecksContentFilterResult";
const _GCCFRE = "GuardrailChecksContentFilterResultEntry";
const _GCCFRL = "GuardrailChecksContentFilterResultList";
const _GCCFU = "GuardrailChecksContentFilterUsage";
const _GCF = "GuardrailContentFilter";
const _GCFL = "GuardrailContentFilterList";
const _GCGF = "GuardrailContextualGroundingFilter";
const _GCGFu = "GuardrailContextualGroundingFilters";
const _GCGPA = "GuardrailContextualGroundingPolicyAssessment";
const _GCIB = "GuardrailConverseImageBlock";
const _GCIS = "GuardrailConverseImageSource";
const _GCM = "GuardrailChecksMessage";
const _GCML = "GuardrailChecksMessageList";
const _GCPA = "GuardrailContentPolicyAssessment";
const _GCPAC = "GuardrailChecksPromptAttackConfig";
const _GCPACC = "GuardrailChecksPromptAttackCategoryConfig";
const _GCPACCL = "GuardrailChecksPromptAttackCategoryConfigList";
const _GCPAR = "GuardrailChecksPromptAttackResult";
const _GCPARE = "GuardrailChecksPromptAttackResultEntry";
const _GCPARL = "GuardrailChecksPromptAttackResultList";
const _GCPAU = "GuardrailChecksPromptAttackUsage";
const _GCR = "GuardrailChecksResults";
const _GCSIC = "GuardrailChecksSensitiveInformationConfig";
const _GCSIEC = "GuardrailChecksSensitiveInformationEntityConfig";
const _GCSIECL = "GuardrailChecksSensitiveInformationEntityConfigList";
const _GCSIR = "GuardrailChecksSensitiveInformationResult";
const _GCSIRE = "GuardrailChecksSensitiveInformationResultEntry";
const _GCSIRL = "GuardrailChecksSensitiveInformationResultList";
const _GCSIU = "GuardrailChecksSensitiveInformationUsage";
const _GCTB = "GuardrailConverseTextBlock";
const _GCTC = "GuardrailChecksTextContent";
const _GCUR = "GuardrailChecksUsageResults";
const _GCW = "GuardrailCustomWord";
const _GCWL = "GuardrailCustomWordList";
const _GCu = "GuardrailCoverage";
const _GIB = "GuardrailImageBlock";
const _GIC = "GuardrailImageCoverage";
const _GIM = "GuardrailInvocationMetrics";
const _GIS = "GuardrailImageSource";
const _GMW = "GuardrailManagedWord";
const _GMWL = "GuardrailManagedWordList";
const _GOC = "GuardrailOutputContent";
const _GOCL = "GuardrailOutputContentList";
const _GPEF = "GuardrailPiiEntityFilter";
const _GPEFL = "GuardrailPiiEntityFilterList";
const _GRF = "GuardrailRegexFilter";
const _GRFL = "GuardrailRegexFilterList";
const _GSC = "GuardrailStreamConfiguration";
const _GSIPA = "GuardrailSensitiveInformationPolicyAssessment";
const _GT = "GuardrailTopic";
const _GTA = "GuardrailTraceAssessment";
const _GTB = "GuardrailTextBlock";
const _GTCC = "GuardrailTextCharactersCoverage";
const _GTL = "GuardrailTopicList";
const _GTPA = "GuardrailTopicPolicyAssessment";
const _GU = "GuardrailUsage";
const _GWPA = "GuardrailWordPolicyAssessment";
const _IB = "ImageBlock";
const _IBD = "ImageBlockDelta";
const _IBS = "ImageBlockStart";
const _IC = "InferenceConfiguration";
const _IGC = "InvokeGuardrailChecks";
const _IGCR = "InvokeGuardrailChecksRequest";
const _IGCRn = "InvokeGuardrailChecksResponse";
const _IM = "InvokeModel";
const _IMR = "InvokeModelRequest";
const _IMRn = "InvokeModelResponse";
const _IMTR = "InvokeModelTokensRequest";
const _IMWBS = "InvokeModelWithBidirectionalStream";
const _IMWBSI = "InvokeModelWithBidirectionalStreamInput";
const _IMWBSO = "InvokeModelWithBidirectionalStreamOutput";
const _IMWBSR = "InvokeModelWithBidirectionalStreamRequest";
const _IMWBSRn = "InvokeModelWithBidirectionalStreamResponse";
const _IMWRS = "InvokeModelWithResponseStream";
const _IMWRSR = "InvokeModelWithResponseStreamRequest";
const _IMWRSRn = "InvokeModelWithResponseStreamResponse";
const _IS = "ImageSource";
const _ISE = "InternalServerException";
const _JSD = "JsonSchemaDefinition";
const _LAI = "ListAsyncInvokes";
const _LAIR = "ListAsyncInvokesRequest";
const _LAIRi = "ListAsyncInvokesResponse";
const _M = "Message";
const _MEE = "ModelErrorException";
const _MIP = "ModelInputPayload";
const _MNRE = "ModelNotReadyException";
const _MSE = "MessageStartEvent";
const _MSEE = "ModelStreamErrorException";
const _MSEe = "MessageStopEvent";
const _MTE = "ModelTimeoutException";
const _Me = "Messages";
const _OC = "OutputConfig";
const _OF = "OutputFormat";
const _OFS = "OutputFormatStructure";
const _PB = "PartBody";
const _PC = "PerformanceConfiguration";
const _PP = "PayloadPart";
const _PRT = "PromptRouterTrace";
const _PVM = "PromptVariableMap";
const _PVV = "PromptVariableValues";
const _RCB = "ReasoningContentBlock";
const _RCBD = "ReasoningContentBlockDelta";
const _RM = "RequestMetadata";
const _RMJ = "RequestMetadataJson";
const _RNFE = "ResourceNotFoundException";
const _RS = "ResponseStream";
const _RTB = "ReasoningTextBlock";
const _SAI = "StartAsyncInvoke";
const _SAIR = "StartAsyncInvokeRequest";
const _SAIRt = "StartAsyncInvokeResponse";
const _SCB = "SystemContentBlocks";
const _SCBy = "SystemContentBlock";
const _SL = "S3Location";
const _SQEE = "ServiceQuotaExceededException";
const _SRB = "SearchResultBlock";
const _SRCB = "SearchResultContentBlock";
const _SRCBe = "SearchResultContentBlocks";
const _SRL = "SearchResultLocation";
const _ST = "ServiceTier";
const _STC = "SpecificToolChoice";
const _STy = "SystemTool";
const _SUE = "ServiceUnavailableException";
const _T = "Tag";
const _TC = "ToolConfiguration";
const _TCo = "ToolChoice";
const _TE = "ThrottlingException";
const _TIS = "ToolInputSchema";
const _TL = "TagList";
const _TRB = "ToolResultBlock";
const _TRBD = "ToolResultBlocksDelta";
const _TRBDo = "ToolResultBlockDelta";
const _TRBS = "ToolResultBlockStart";
const _TRCB = "ToolResultContentBlocks";
const _TRCBo = "ToolResultContentBlock";
const _TS = "ToolSpecification";
const _TU = "TokenUsage";
const _TUB = "ToolUseBlock";
const _TUBD = "ToolUseBlockDelta";
const _TUBS = "ToolUseBlockStart";
const _To = "Tools";
const _Too = "Tool";
const _VB = "VideoBlock";
const _VE = "ValidationException";
const _VS = "VideoSource";
const _WL = "WebLocation";
const _XABA = "X-Amzn-Bedrock-Accept";
const _XABCT = "X-Amzn-Bedrock-Content-Type";
const _XABG = "X-Amzn-Bedrock-GuardrailIdentifier";
const _XABG_ = "X-Amzn-Bedrock-GuardrailVersion";
const _XABPL = "X-Amzn-Bedrock-PerformanceConfig-Latency";
const _XABRM = "X-Amzn-Bedrock-Request-Metadata";
const _XABST = "X-Amzn-Bedrock-Service-Tier";
const _XABT = "X-Amzn-Bedrock-Trace";
const _a = "action";
const _aGD = "appliedGuardrailDetails";
const _aIS = "asyncInvokeSummaries";
const _aMRF = "additionalModelRequestFields";
const _aMRFP = "additionalModelResponseFieldPaths";
const _aMRFd = "additionalModelResponseFields";
const _aR = "actionReason";
const _aRP = "automatedReasoningPolicy";
const _aRPU = "automatedReasoningPolicyUnits";
const _aRPu = "automatedReasoningPolicies";
const _ac = "accept";
const _an = "any";
const _as = "assessments";
const _au = "audio";
const _aut = "auto";
const _b = "bytes";
const _bO = "bucketOwner";
const _bOe = "beginOffset";
const _bo = "body";
const _c = "client";
const _cBD = "contentBlockDelta";
const _cBI = "contentBlockIndex";
const _cBS = "contentBlockStart";
const _cBSo = "contentBlockStop";
const _cC = "citationsContent";
const _cD = "cacheDetails";
const _cF = "contentFilter";
const _cFS = "claimsFalseScenario";
const _cGP = "contextualGroundingPolicy";
const _cGPU = "contextualGroundingPolicyUnits";
const _cI = "contentIndex";
const _cP = "contentPolicy";
const _cPIU = "contentPolicyImageUnits";
const _cPU = "contentPolicyUnits";
const _cPa = "cachePoint";
const _cR = "contradictingRules";
const _cRIT = "cacheReadInputTokens";
const _cRT = "clientRequestToken";
const _cS = "confidenceScore";
const _cT = "contentType";
const _cTS = "claimsTrueScenario";
const _cW = "customWords";
const _cWIT = "cacheWriteInputTokens";
const _ca = "category";
const _cat = "categories";
const _ch = "checks";
const _chu = "chunk";
const _ci = "citations";
const _cit = "citation";
const _cl = "claims";
const _co = "content";
const _con = "context";
const _conf = "confidence";
const _conv = "converse";
const _d = "delta";
const _dC = "documentChar";
const _dCo = "documentChunk";
const _dI = "documentIndex";
const _dP = "documentPage";
const _dS = "differenceScenarios";
const _de = "detected";
const _des = "description";
const _do = "domain";
const _doc = "document";
const _e = "error";
const _eO = "endOffset";
const _eT = "endTime";
const _en = "enabled";
const _end = "end";
const _ent = "entities";
const _f = "format";
const _fM = "failureMessage";
const _fS = "filterStrength";
const _fi = "findings";
const _fil = "filters";
const _g = "guardrail";
const _gA = "guardrailArn";
const _gC = "guardrailCoverage";
const _gCu = "guardrailConfig";
const _gCua = "guardContent";
const _gI = "guardrailId";
const _gIu = "guardrailIdentifier";
const _gO = "guardrailOrigin";
const _gOu = "guardrailOwnership";
const _gPL = "guardrailProcessingLatency";
const _gV = "guardrailVersion";
const _gu = "guarded";
const _h = "http";
const _hE = "httpError";
const _hH = "httpHeader";
const _hQ = "httpQuery";
const _i = "input";
const _iA = "invocationArn";
const _iAn = "inputAssessment";
const _iC = "inferenceConfig";
const _iM = "invocationMetrics";
const _iMI = "invokedModelId";
const _iMn = "invokeModel";
const _iS = "inputSchema";
const _iSE = "internalServerException";
const _iT = "inputTokens";
const _id = "identifier";
const _im = "images";
const _ima = "image";
const _imp = "impossible";
const _in = "invalid";
const _j = "json";
const _jS = "jsonSchema";
const _k = "key";
const _kKI = "kmsKeyId";
const _l = "location";
const _lM = "latencyMs";
const _lMT = "lastModifiedTime";
const _lW = "logicWarning";
const _la = "latency";
const _lo = "logic";
const _m = "message";
const _mA = "modelArn";
const _mI = "modelId";
const _mIe = "messageIndex";
const _mIo = "modelInput";
const _mO = "modelOutput";
const _mR = "maxResults";
const _mS = "messageStart";
const _mSEE = "modelStreamErrorException";
const _mSe = "messageStop";
const _mT = "maxTokens";
const _mTE = "modelTimeoutException";
const _mWL = "managedWordLists";
const _ma = "match";
const _me = "messages";
const _met = "metrics";
const _meta = "metadata";
const _n = "name";
const _nL = "naturalLanguage";
const _nT = "nextToken";
const _nTo = "noTranslations";
const _o = "outputs";
const _oA = "outputAssessments";
const _oC = "outputConfig";
const _oDC = "outputDataConfig";
const _oM = "originalMessage";
const _oS = "outputScope";
const _oSC = "originalStatusCode";
const _oT = "outputTokens";
const _op = "options";
const _ou = "output";
const _p = "premises";
const _pA = "promptAttack";
const _pC = "performanceConfig";
const _pCL = "performanceConfigLatency";
const _pE = "piiEntities";
const _pR = "promptRouter";
const _pV = "promptVariables";
const _pVA = "policyVersionArn";
const _q = "qualifiers";
const _r = "results";
const _rC = "reasoningContent";
const _rCe = "redactedContent";
const _rM = "requestMetadata";
const _rN = "resourceName";
const _rT = "reasoningText";
const _re = "regex";
const _reg = "regexes";
const _ro = "role";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.bedrockruntime";
const _sB = "sortBy";
const _sC = "sourceContent";
const _sE = "statusEquals";
const _sI = "sensitiveInformation";
const _sIP = "sensitiveInformationPolicy";
const _sIPFU = "sensitiveInformationPolicyFreeUnits";
const _sIPU = "sensitiveInformationPolicyUnits";
const _sL = "s3Location";
const _sO = "sortOrder";
const _sODC = "s3OutputDataConfig";
const _sPM = "streamProcessingMode";
const _sR = "stopReason";
const _sRI = "searchResultIndex";
const _sRL = "searchResultLocation";
const _sRe = "searchResult";
const _sRu = "supportingRules";
const _sS = "severityScore";
const _sSt = "stopSequences";
const _sT = "submitTime";
const _sTA = "submitTimeAfter";
const _sTB = "submitTimeBefore";
const _sTe = "serviceTier";
const _sTy = "systemTool";
const _sU = "s3Uri";
const _sUE = "serviceUnavailableException";
const _sa = "satisfiable";
const _sc = "score";
const _sch = "schema";
const _se = "server";
const _si = "signature";
const _so = "source";
const _st = "status";
const _sta = "start";
const _stat = "statements";
const _str = "stream";
const _stre = "streaming";
const _stri = "strict";
const _stru = "structure";
const _sy = "system";
const _t = "ttl";
const _tA = "translationAmbiguous";
const _tC = "toolConfig";
const _tCe = "textCharacters";
const _tCo = "toolChoice";
const _tCoo = "tooComplex";
const _tE = "throttlingException";
const _tF = "textFormat";
const _tP = "topicPolicy";
const _tPU = "topicPolicyUnits";
const _tPo = "topP";
const _tR = "toolResult";
const _tS = "toolSpec";
const _tT = "totalTokens";
const _tU = "textUnits";
const _tUI = "toolUseId";
const _tUo = "toolUse";
const _ta = "tags";
const _te = "text";
const _tem = "temperature";
const _th = "threshold";
const _ti = "title";
const _to = "total";
const _too = "tools";
const _tool = "tool";
const _top = "topics";
const _tr = "trace";
const _tra = "translation";
const _tran = "translations";
const _tru = "truncated";
const _ty = "type";
const _u = "usage";
const _uC = "untranslatedClaims";
const _uP = "untranslatedPremises";
const _ur = "uri";
const _url = "url";
const _v = "value";
const _vE = "validationException";
const _va = "valid";
const _vi = "video";
const _w = "web";
const _wP = "wordPolicy";
const _wPU = "wordPolicyUnits";
const n0 = "com.amazonaws.bedrockruntime";
const _s_registry = TypeRegistry.for(_s);
var BedrockRuntimeServiceException$ = [-3, _s, "BedrockRuntimeServiceException", 0, [], []];
_s_registry.registerError(BedrockRuntimeServiceException$, BedrockRuntimeServiceException);
const n0_registry = TypeRegistry.for(n0);
var AccessDeniedException$ = [-3, n0, _ADE,
    { [_e]: _c, [_hE]: 403 },
    [_m],
    [0]
];
n0_registry.registerError(AccessDeniedException$, AccessDeniedException);
var ConflictException$ = [-3, n0, _CE,
    { [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
n0_registry.registerError(ConflictException$, ConflictException);
var InternalServerException$ = [-3, n0, _ISE,
    { [_e]: _se, [_hE]: 500 },
    [_m],
    [0]
];
n0_registry.registerError(InternalServerException$, InternalServerException);
var ModelErrorException$ = [-3, n0, _MEE,
    { [_e]: _c, [_hE]: 424 },
    [_m, _oSC, _rN],
    [0, 1, 0]
];
n0_registry.registerError(ModelErrorException$, ModelErrorException);
var ModelNotReadyException$ = [-3, n0, _MNRE,
    { [_e]: _c, [_hE]: 429 },
    [_m],
    [0]
];
n0_registry.registerError(ModelNotReadyException$, ModelNotReadyException);
var ModelStreamErrorException$ = [-3, n0, _MSEE,
    { [_e]: _c, [_hE]: 424 },
    [_m, _oSC, _oM],
    [0, 1, 0]
];
n0_registry.registerError(ModelStreamErrorException$, ModelStreamErrorException);
var ModelTimeoutException$ = [-3, n0, _MTE,
    { [_e]: _c, [_hE]: 408 },
    [_m],
    [0]
];
n0_registry.registerError(ModelTimeoutException$, ModelTimeoutException);
var ResourceNotFoundException$ = [-3, n0, _RNFE,
    { [_e]: _c, [_hE]: 404 },
    [_m],
    [0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var ServiceQuotaExceededException$ = [-3, n0, _SQEE,
    { [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
n0_registry.registerError(ServiceQuotaExceededException$, ServiceQuotaExceededException);
var ServiceUnavailableException$ = [-3, n0, _SUE,
    { [_e]: _se, [_hE]: 503 },
    [_m],
    [0]
];
n0_registry.registerError(ServiceUnavailableException$, ServiceUnavailableException);
var ThrottlingException$ = [-3, n0, _TE,
    { [_e]: _c, [_hE]: 429 },
    [_m],
    [0]
];
n0_registry.registerError(ThrottlingException$, ThrottlingException);
var ValidationException$ = [-3, n0, _VE,
    { [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
n0_registry.registerError(ValidationException$, ValidationException);
const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var AsyncInvokeMessage = [0, n0, _AIM, 8, 0];
var Body = [0, n0, _B, 8, 21];
var GuardrailAutomatedReasoningStatementLogicContent = [0, n0, _GARSLC, 8, 0];
var GuardrailAutomatedReasoningStatementNaturalLanguageContent = [0, n0, _GARSNLC, 8, 0];
var GuardrailChecksTextContent = [0, n0, _GCTC, 8, 0];
var ModelInputPayload = [0, n0, _MIP, 8, 15];
var PartBody = [0, n0, _PB, 8, 21];
var RequestMetadataJson = [0, n0, _RMJ, 8, 0];
var AnyToolChoice$ = [3, n0, _ATC,
    0,
    [],
    []
];
var AppliedGuardrailDetails$ = [3, n0, _AGD,
    0,
    [_gI, _gV, _gA, _gO, _gOu],
    [0, 0, 0, 64 | 0, 0]
];
var ApplyGuardrailRequest$ = [3, n0, _AGR,
    0,
    [_gIu, _gV, _so, _co, _oS],
    [[0, 1], [0, 1], 0, [() => GuardrailContentBlockList, 0], 0], 4
];
var ApplyGuardrailResponse$ = [3, n0, _AGRp,
    0,
    [_u, _a, _o, _as, _aR, _gC],
    [() => GuardrailUsage$, 0, () => GuardrailOutputContentList, [() => GuardrailAssessmentList, 0], 0, () => GuardrailCoverage$], 4
];
var AsyncInvokeS3OutputDataConfig$ = [3, n0, _AISODC,
    0,
    [_sU, _kKI, _bO],
    [0, 0, 0], 1
];
var AsyncInvokeSummary$ = [3, n0, _AIS,
    0,
    [_iA, _mA, _sT, _oDC, _cRT, _st, _fM, _lMT, _eT],
    [0, 0, 5, () => AsyncInvokeOutputDataConfig$, 0, 0, [() => AsyncInvokeMessage, 0], 5, 5], 4
];
var AudioBlock$ = [3, n0, _AB,
    0,
    [_f, _so, _e],
    [0, [() => AudioSource$, 0], [() => ErrorBlock$, 0]], 2
];
var AutoToolChoice$ = [3, n0, _ATCu,
    0,
    [],
    []
];
var BidirectionalInputPayloadPart$ = [3, n0, _BIPP,
    8,
    [_b],
    [[() => PartBody, 0]]
];
var BidirectionalOutputPayloadPart$ = [3, n0, _BOPP,
    8,
    [_b],
    [[() => PartBody, 0]]
];
var CacheDetail$ = [3, n0, _CD,
    0,
    [_t, _iT],
    [0, 1], 2
];
var CachePointBlock$ = [3, n0, _CPB,
    0,
    [_ty, _t],
    [0, 0], 1
];
var Citation$ = [3, n0, _C,
    0,
    [_ti, _so, _sC, _l],
    [0, 0, () => CitationSourceContentList, () => CitationLocation$]
];
var CitationsConfig$ = [3, n0, _CC,
    0,
    [_en],
    [2], 1
];
var CitationsContentBlock$ = [3, n0, _CCB,
    0,
    [_co, _ci],
    [() => CitationGeneratedContentList, () => Citations]
];
var CitationsDelta$ = [3, n0, _CDi,
    0,
    [_ti, _so, _sC, _l],
    [0, 0, () => CitationSourceContentListDelta, () => CitationLocation$]
];
var CitationSourceContentDelta$ = [3, n0, _CSCD,
    0,
    [_te],
    [0]
];
var ContentBlockDeltaEvent$ = [3, n0, _CBDE,
    0,
    [_d, _cBI],
    [[() => ContentBlockDelta$, 0], 1], 2
];
var ContentBlockStartEvent$ = [3, n0, _CBSE,
    0,
    [_sta, _cBI],
    [() => ContentBlockStart$, 1], 2
];
var ContentBlockStopEvent$ = [3, n0, _CBSEo,
    0,
    [_cBI],
    [1], 1
];
var ConverseMetrics$ = [3, n0, _CM,
    0,
    [_lM],
    [1], 1
];
var ConverseRequest$ = [3, n0, _CR,
    0,
    [_mI, _me, _sy, _iC, _tC, _gCu, _aMRF, _pV, _aMRFP, _rM, _pC, _sTe, _oC],
    [[0, 1], [() => Messages, 0], [() => SystemContentBlocks, 0], () => InferenceConfiguration$, () => ToolConfiguration$, () => GuardrailConfiguration$, 15, [() => PromptVariableMap, 0], 64 | 0, [() => RequestMetadata, 0], () => PerformanceConfiguration$, () => ServiceTier$, [() => OutputConfig$, 0]], 1
];
var ConverseResponse$ = [3, n0, _CRo,
    0,
    [_ou, _sR, _u, _met, _aMRFd, _tr, _pC, _sTe],
    [[() => ConverseOutput$, 0], 0, () => TokenUsage$, () => ConverseMetrics$, 15, [() => ConverseTrace$, 0], () => PerformanceConfiguration$, () => ServiceTier$], 4
];
var ConverseStreamMetadataEvent$ = [3, n0, _CSME,
    0,
    [_u, _met, _tr, _pC, _sTe],
    [() => TokenUsage$, () => ConverseStreamMetrics$, [() => ConverseStreamTrace$, 0], () => PerformanceConfiguration$, () => ServiceTier$], 2
];
var ConverseStreamMetrics$ = [3, n0, _CSM,
    0,
    [_lM],
    [1], 1
];
var ConverseStreamRequest$ = [3, n0, _CSR,
    0,
    [_mI, _me, _sy, _iC, _tC, _gCu, _aMRF, _pV, _aMRFP, _rM, _pC, _sTe, _oC],
    [[0, 1], [() => Messages, 0], [() => SystemContentBlocks, 0], () => InferenceConfiguration$, () => ToolConfiguration$, () => GuardrailStreamConfiguration$, 15, [() => PromptVariableMap, 0], 64 | 0, [() => RequestMetadata, 0], () => PerformanceConfiguration$, () => ServiceTier$, [() => OutputConfig$, 0]], 1
];
var ConverseStreamResponse$ = [3, n0, _CSRo,
    0,
    [_str],
    [[() => ConverseStreamOutput$, 16]]
];
var ConverseStreamTrace$ = [3, n0, _CST,
    0,
    [_g, _pR],
    [[() => GuardrailTraceAssessment$, 0], () => PromptRouterTrace$]
];
var ConverseTokensRequest$ = [3, n0, _CTR,
    0,
    [_me, _sy, _tC, _aMRF],
    [[() => Messages, 0], [() => SystemContentBlocks, 0], () => ToolConfiguration$, 15]
];
var ConverseTrace$ = [3, n0, _CT,
    0,
    [_g, _pR],
    [[() => GuardrailTraceAssessment$, 0], () => PromptRouterTrace$]
];
var CountTokensRequest$ = [3, n0, _CTRo,
    0,
    [_mI, _i],
    [[0, 1], [() => CountTokensInput$, 0]], 2
];
var CountTokensResponse$ = [3, n0, _CTRou,
    0,
    [_iT],
    [1], 1
];
var DocumentBlock$ = [3, n0, _DB,
    0,
    [_n, _so, _f, _con, _ci],
    [0, () => DocumentSource$, 0, 0, () => CitationsConfig$], 2
];
var DocumentCharLocation$ = [3, n0, _DCL,
    0,
    [_dI, _sta, _end],
    [1, 1, 1]
];
var DocumentChunkLocation$ = [3, n0, _DCLo,
    0,
    [_dI, _sta, _end],
    [1, 1, 1]
];
var DocumentPageLocation$ = [3, n0, _DPL,
    0,
    [_dI, _sta, _end],
    [1, 1, 1]
];
var ErrorBlock$ = [3, n0, _EB,
    8,
    [_m],
    [0]
];
var GetAsyncInvokeRequest$ = [3, n0, _GAIR,
    0,
    [_iA],
    [[0, 1]], 1
];
var GetAsyncInvokeResponse$ = [3, n0, _GAIRe,
    0,
    [_iA, _mA, _st, _sT, _oDC, _cRT, _fM, _lMT, _eT],
    [0, 0, 0, 5, () => AsyncInvokeOutputDataConfig$, 0, [() => AsyncInvokeMessage, 0], 5, 5], 5
];
var GuardrailAssessment$ = [3, n0, _GA,
    0,
    [_tP, _cP, _wP, _sIP, _cGP, _aRP, _iM, _aGD],
    [() => GuardrailTopicPolicyAssessment$, () => GuardrailContentPolicyAssessment$, () => GuardrailWordPolicyAssessment$, () => GuardrailSensitiveInformationPolicyAssessment$, () => GuardrailContextualGroundingPolicyAssessment$, [() => GuardrailAutomatedReasoningPolicyAssessment$, 0], () => GuardrailInvocationMetrics$, () => AppliedGuardrailDetails$]
];
var GuardrailAutomatedReasoningImpossibleFinding$ = [3, n0, _GARIF,
    0,
    [_tra, _cR, _lW],
    [[() => GuardrailAutomatedReasoningTranslation$, 0], () => GuardrailAutomatedReasoningRuleList, [() => GuardrailAutomatedReasoningLogicWarning$, 0]]
];
var GuardrailAutomatedReasoningInputTextReference$ = [3, n0, _GARITR,
    0,
    [_te],
    [[() => GuardrailAutomatedReasoningStatementNaturalLanguageContent, 0]]
];
var GuardrailAutomatedReasoningInvalidFinding$ = [3, n0, _GARIFu,
    0,
    [_tra, _cR, _lW],
    [[() => GuardrailAutomatedReasoningTranslation$, 0], () => GuardrailAutomatedReasoningRuleList, [() => GuardrailAutomatedReasoningLogicWarning$, 0]]
];
var GuardrailAutomatedReasoningLogicWarning$ = [3, n0, _GARLW,
    0,
    [_ty, _p, _cl],
    [0, [() => GuardrailAutomatedReasoningStatementList, 0], [() => GuardrailAutomatedReasoningStatementList, 0]]
];
var GuardrailAutomatedReasoningNoTranslationsFinding$ = [3, n0, _GARNTF,
    0,
    [],
    []
];
var GuardrailAutomatedReasoningPolicyAssessment$ = [3, n0, _GARPA,
    0,
    [_fi],
    [[() => GuardrailAutomatedReasoningFindingList, 0]]
];
var GuardrailAutomatedReasoningRule$ = [3, n0, _GARR,
    0,
    [_id, _pVA],
    [0, 0]
];
var GuardrailAutomatedReasoningSatisfiableFinding$ = [3, n0, _GARSF,
    0,
    [_tra, _cTS, _cFS, _lW],
    [[() => GuardrailAutomatedReasoningTranslation$, 0], [() => GuardrailAutomatedReasoningScenario$, 0], [() => GuardrailAutomatedReasoningScenario$, 0], [() => GuardrailAutomatedReasoningLogicWarning$, 0]]
];
var GuardrailAutomatedReasoningScenario$ = [3, n0, _GARS,
    0,
    [_stat],
    [[() => GuardrailAutomatedReasoningStatementList, 0]]
];
var GuardrailAutomatedReasoningStatement$ = [3, n0, _GARSu,
    0,
    [_lo, _nL],
    [[() => GuardrailAutomatedReasoningStatementLogicContent, 0], [() => GuardrailAutomatedReasoningStatementNaturalLanguageContent, 0]]
];
var GuardrailAutomatedReasoningTooComplexFinding$ = [3, n0, _GARTCF,
    0,
    [],
    []
];
var GuardrailAutomatedReasoningTranslation$ = [3, n0, _GART,
    0,
    [_p, _cl, _uP, _uC, _conf],
    [[() => GuardrailAutomatedReasoningStatementList, 0], [() => GuardrailAutomatedReasoningStatementList, 0], [() => GuardrailAutomatedReasoningInputTextReferenceList, 0], [() => GuardrailAutomatedReasoningInputTextReferenceList, 0], 1]
];
var GuardrailAutomatedReasoningTranslationAmbiguousFinding$ = [3, n0, _GARTAF,
    0,
    [_op, _dS],
    [[() => GuardrailAutomatedReasoningTranslationOptionList, 0], [() => GuardrailAutomatedReasoningDifferenceScenarioList, 0]]
];
var GuardrailAutomatedReasoningTranslationOption$ = [3, n0, _GARTO,
    0,
    [_tran],
    [[() => GuardrailAutomatedReasoningTranslationList, 0]]
];
var GuardrailAutomatedReasoningValidFinding$ = [3, n0, _GARVF,
    0,
    [_tra, _cTS, _sRu, _lW],
    [[() => GuardrailAutomatedReasoningTranslation$, 0], [() => GuardrailAutomatedReasoningScenario$, 0], () => GuardrailAutomatedReasoningRuleList, [() => GuardrailAutomatedReasoningLogicWarning$, 0]]
];
var GuardrailChecksConfig$ = [3, n0, _GCC,
    0,
    [_cF, _pA, _sI],
    [() => GuardrailChecksContentFilterConfig$, () => GuardrailChecksPromptAttackConfig$, () => GuardrailChecksSensitiveInformationConfig$]
];
var GuardrailChecksContentFilterCategoryConfig$ = [3, n0, _GCCFCC,
    0,
    [_ca],
    [0], 1
];
var GuardrailChecksContentFilterConfig$ = [3, n0, _GCCFC,
    0,
    [_cat],
    [() => GuardrailChecksContentFilterCategoryConfigList], 1
];
var GuardrailChecksContentFilterResult$ = [3, n0, _GCCFR,
    0,
    [_r],
    [() => GuardrailChecksContentFilterResultList], 1
];
var GuardrailChecksContentFilterResultEntry$ = [3, n0, _GCCFRE,
    0,
    [_ca, _sS],
    [0, 1], 2
];
var GuardrailChecksContentFilterUsage$ = [3, n0, _GCCFU,
    0,
    [_tU],
    [1], 1
];
var GuardrailChecksMessage$ = [3, n0, _GCM,
    0,
    [_ro, _co],
    [0, [() => GuardrailChecksContentBlockList, 0]], 2
];
var GuardrailChecksPromptAttackCategoryConfig$ = [3, n0, _GCPACC,
    0,
    [_ca],
    [0], 1
];
var GuardrailChecksPromptAttackConfig$ = [3, n0, _GCPAC,
    0,
    [_cat],
    [() => GuardrailChecksPromptAttackCategoryConfigList], 1
];
var GuardrailChecksPromptAttackResult$ = [3, n0, _GCPAR,
    0,
    [_r],
    [() => GuardrailChecksPromptAttackResultList], 1
];
var GuardrailChecksPromptAttackResultEntry$ = [3, n0, _GCPARE,
    0,
    [_ca, _sS],
    [0, 1], 2
];
var GuardrailChecksPromptAttackUsage$ = [3, n0, _GCPAU,
    0,
    [_tU],
    [1], 1
];
var GuardrailChecksResults$ = [3, n0, _GCR,
    0,
    [_cF, _pA, _sI],
    [() => GuardrailChecksContentFilterResult$, () => GuardrailChecksPromptAttackResult$, () => GuardrailChecksSensitiveInformationResult$]
];
var GuardrailChecksSensitiveInformationConfig$ = [3, n0, _GCSIC,
    0,
    [_ent],
    [() => GuardrailChecksSensitiveInformationEntityConfigList], 1
];
var GuardrailChecksSensitiveInformationEntityConfig$ = [3, n0, _GCSIEC,
    0,
    [_ty],
    [0], 1
];
var GuardrailChecksSensitiveInformationResult$ = [3, n0, _GCSIR,
    0,
    [_r, _tru],
    [() => GuardrailChecksSensitiveInformationResultList, 2], 1
];
var GuardrailChecksSensitiveInformationResultEntry$ = [3, n0, _GCSIRE,
    0,
    [_ty, _cS, _bOe, _eO, _mIe, _cI],
    [0, 1, 1, 1, 1, 1], 6
];
var GuardrailChecksSensitiveInformationUsage$ = [3, n0, _GCSIU,
    0,
    [_tU],
    [1], 1
];
var GuardrailChecksUsageResults$ = [3, n0, _GCUR,
    0,
    [_cF, _pA, _sI],
    [() => GuardrailChecksContentFilterUsage$, () => GuardrailChecksPromptAttackUsage$, () => GuardrailChecksSensitiveInformationUsage$]
];
var GuardrailConfiguration$ = [3, n0, _GC,
    0,
    [_gIu, _gV, _tr],
    [0, 0, 0]
];
var GuardrailContentFilter$ = [3, n0, _GCF,
    0,
    [_ty, _conf, _a, _fS, _de],
    [0, 0, 0, 0, 2], 3
];
var GuardrailContentPolicyAssessment$ = [3, n0, _GCPA,
    0,
    [_fil],
    [() => GuardrailContentFilterList], 1
];
var GuardrailContextualGroundingFilter$ = [3, n0, _GCGF,
    0,
    [_ty, _th, _sc, _a, _de],
    [0, 1, 1, 0, 2], 4
];
var GuardrailContextualGroundingPolicyAssessment$ = [3, n0, _GCGPA,
    0,
    [_fil],
    [() => GuardrailContextualGroundingFilters]
];
var GuardrailConverseImageBlock$ = [3, n0, _GCIB,
    8,
    [_f, _so],
    [0, [() => GuardrailConverseImageSource$, 0]], 2
];
var GuardrailConverseTextBlock$ = [3, n0, _GCTB,
    0,
    [_te, _q],
    [0, 64 | 0], 1
];
var GuardrailCoverage$ = [3, n0, _GCu,
    0,
    [_tCe, _im],
    [() => GuardrailTextCharactersCoverage$, () => GuardrailImageCoverage$]
];
var GuardrailCustomWord$ = [3, n0, _GCW,
    0,
    [_ma, _a, _de],
    [0, 0, 2], 2
];
var GuardrailImageBlock$ = [3, n0, _GIB,
    8,
    [_f, _so],
    [0, [() => GuardrailImageSource$, 0]], 2
];
var GuardrailImageCoverage$ = [3, n0, _GIC,
    0,
    [_gu, _to],
    [1, 1]
];
var GuardrailInvocationMetrics$ = [3, n0, _GIM,
    0,
    [_gPL, _u, _gC],
    [1, () => GuardrailUsage$, () => GuardrailCoverage$]
];
var GuardrailManagedWord$ = [3, n0, _GMW,
    0,
    [_ma, _ty, _a, _de],
    [0, 0, 0, 2], 3
];
var GuardrailOutputContent$ = [3, n0, _GOC,
    0,
    [_te],
    [0]
];
var GuardrailPiiEntityFilter$ = [3, n0, _GPEF,
    0,
    [_ma, _ty, _a, _de],
    [0, 0, 0, 2], 3
];
var GuardrailRegexFilter$ = [3, n0, _GRF,
    0,
    [_a, _n, _ma, _re, _de],
    [0, 0, 0, 0, 2], 1
];
var GuardrailSensitiveInformationPolicyAssessment$ = [3, n0, _GSIPA,
    0,
    [_pE, _reg],
    [() => GuardrailPiiEntityFilterList, () => GuardrailRegexFilterList], 2
];
var GuardrailStreamConfiguration$ = [3, n0, _GSC,
    0,
    [_gIu, _gV, _tr, _sPM],
    [0, 0, 0, 0]
];
var GuardrailTextBlock$ = [3, n0, _GTB,
    0,
    [_te, _q],
    [0, 64 | 0], 1
];
var GuardrailTextCharactersCoverage$ = [3, n0, _GTCC,
    0,
    [_gu, _to],
    [1, 1]
];
var GuardrailTopic$ = [3, n0, _GT,
    0,
    [_n, _ty, _a, _de],
    [0, 0, 0, 2], 3
];
var GuardrailTopicPolicyAssessment$ = [3, n0, _GTPA,
    0,
    [_top],
    [() => GuardrailTopicList], 1
];
var GuardrailTraceAssessment$ = [3, n0, _GTA,
    0,
    [_mO, _iAn, _oA, _aR],
    [64 | 0, [() => GuardrailAssessmentMap, 0], [() => GuardrailAssessmentListMap, 0], 0]
];
var GuardrailUsage$ = [3, n0, _GU,
    0,
    [_tPU, _cPU, _wPU, _sIPU, _sIPFU, _cGPU, _cPIU, _aRPU, _aRPu],
    [1, 1, 1, 1, 1, 1, 1, 1, 1], 6
];
var GuardrailWordPolicyAssessment$ = [3, n0, _GWPA,
    0,
    [_cW, _mWL],
    [() => GuardrailCustomWordList, () => GuardrailManagedWordList], 2
];
var ImageBlock$ = [3, n0, _IB,
    0,
    [_f, _so, _e],
    [0, [() => ImageSource$, 0], [() => ErrorBlock$, 0]], 2
];
var ImageBlockDelta$ = [3, n0, _IBD,
    0,
    [_so, _e],
    [[() => ImageSource$, 0], [() => ErrorBlock$, 0]]
];
var ImageBlockStart$ = [3, n0, _IBS,
    0,
    [_f],
    [0], 1
];
var InferenceConfiguration$ = [3, n0, _IC,
    0,
    [_mT, _tem, _tPo, _sSt],
    [1, 1, 1, 64 | 0]
];
var InvokeGuardrailChecksRequest$ = [3, n0, _IGCR,
    0,
    [_me, _ch],
    [[() => GuardrailChecksMessageList, 0], () => GuardrailChecksConfig$], 2
];
var InvokeGuardrailChecksResponse$ = [3, n0, _IGCRn,
    0,
    [_r, _u],
    [() => GuardrailChecksResults$, () => GuardrailChecksUsageResults$], 2
];
var InvokeModelRequest$ = [3, n0, _IMR,
    0,
    [_mI, _bo, _cT, _ac, _tr, _gIu, _gV, _pCL, _sTe, _rM],
    [[0, 1], [() => Body, 16], [0, { [_hH]: _CT_ }], [0, { [_hH]: _A }], [0, { [_hH]: _XABT }], [0, { [_hH]: _XABG }], [0, { [_hH]: _XABG_ }], [0, { [_hH]: _XABPL }], [0, { [_hH]: _XABST }], [() => RequestMetadataJson, { [_hH]: _XABRM }]], 1
];
var InvokeModelResponse$ = [3, n0, _IMRn,
    0,
    [_bo, _cT, _pCL, _sTe],
    [[() => Body, 16], [0, { [_hH]: _CT_ }], [0, { [_hH]: _XABPL }], [0, { [_hH]: _XABST }]], 2
];
var InvokeModelTokensRequest$ = [3, n0, _IMTR,
    0,
    [_bo],
    [[() => Body, 0]], 1
];
var InvokeModelWithBidirectionalStreamRequest$ = [3, n0, _IMWBSR,
    0,
    [_mI, _bo],
    [[0, 1], [() => InvokeModelWithBidirectionalStreamInput$, 16]], 2
];
var InvokeModelWithBidirectionalStreamResponse$ = [3, n0, _IMWBSRn,
    0,
    [_bo],
    [[() => InvokeModelWithBidirectionalStreamOutput$, 16]], 1
];
var InvokeModelWithResponseStreamRequest$ = [3, n0, _IMWRSR,
    0,
    [_mI, _bo, _cT, _ac, _tr, _gIu, _gV, _pCL, _sTe, _rM],
    [[0, 1], [() => Body, 16], [0, { [_hH]: _CT_ }], [0, { [_hH]: _XABA }], [0, { [_hH]: _XABT }], [0, { [_hH]: _XABG }], [0, { [_hH]: _XABG_ }], [0, { [_hH]: _XABPL }], [0, { [_hH]: _XABST }], [() => RequestMetadataJson, { [_hH]: _XABRM }]], 1
];
var InvokeModelWithResponseStreamResponse$ = [3, n0, _IMWRSRn,
    0,
    [_bo, _cT, _pCL, _sTe],
    [[() => ResponseStream$, 16], [0, { [_hH]: _XABCT }], [0, { [_hH]: _XABPL }], [0, { [_hH]: _XABST }]], 2
];
var JsonSchemaDefinition$ = [3, n0, _JSD,
    0,
    [_sch, _n, _des],
    [0, 0, 0], 1
];
var ListAsyncInvokesRequest$ = [3, n0, _LAIR,
    0,
    [_sTA, _sTB, _sE, _mR, _nT, _sB, _sO],
    [[5, { [_hQ]: _sTA }], [5, { [_hQ]: _sTB }], [0, { [_hQ]: _sE }], [1, { [_hQ]: _mR }], [0, { [_hQ]: _nT }], [0, { [_hQ]: _sB }], [0, { [_hQ]: _sO }]]
];
var ListAsyncInvokesResponse$ = [3, n0, _LAIRi,
    0,
    [_nT, _aIS],
    [0, [() => AsyncInvokeSummaries, 0]]
];
var Message$ = [3, n0, _M,
    0,
    [_ro, _co],
    [0, [() => ContentBlocks, 0]], 2
];
var MessageStartEvent$ = [3, n0, _MSE,
    0,
    [_ro],
    [0], 1
];
var MessageStopEvent$ = [3, n0, _MSEe,
    0,
    [_sR, _aMRFd],
    [0, 15], 1
];
var OutputConfig$ = [3, n0, _OC,
    0,
    [_tF],
    [[() => OutputFormat$, 0]]
];
var OutputFormat$ = [3, n0, _OF,
    0,
    [_ty, _stru],
    [0, [() => OutputFormatStructure$, 0]], 2
];
var PayloadPart$ = [3, n0, _PP,
    8,
    [_b],
    [[() => PartBody, 0]]
];
var PerformanceConfiguration$ = [3, n0, _PC,
    0,
    [_la],
    [0]
];
var PromptRouterTrace$ = [3, n0, _PRT,
    0,
    [_iMI],
    [0]
];
var ReasoningTextBlock$ = [3, n0, _RTB,
    8,
    [_te, _si],
    [0, 0], 1
];
var S3Location$ = [3, n0, _SL,
    0,
    [_ur, _bO],
    [0, 0], 1
];
var SearchResultBlock$ = [3, n0, _SRB,
    0,
    [_so, _ti, _co, _ci],
    [0, 0, () => SearchResultContentBlocks, () => CitationsConfig$], 3
];
var SearchResultContentBlock$ = [3, n0, _SRCB,
    0,
    [_te],
    [0], 1
];
var SearchResultLocation$ = [3, n0, _SRL,
    0,
    [_sRI, _sta, _end],
    [1, 1, 1]
];
var ServiceTier$ = [3, n0, _ST,
    0,
    [_ty],
    [0], 1
];
var SpecificToolChoice$ = [3, n0, _STC,
    0,
    [_n],
    [0], 1
];
var StartAsyncInvokeRequest$ = [3, n0, _SAIR,
    0,
    [_mI, _mIo, _oDC, _cRT, _ta],
    [0, [() => ModelInputPayload, 0], () => AsyncInvokeOutputDataConfig$, [0, 4], () => TagList], 3
];
var StartAsyncInvokeResponse$ = [3, n0, _SAIRt,
    0,
    [_iA],
    [0], 1
];
var SystemTool$ = [3, n0, _STy,
    0,
    [_n],
    [0], 1
];
var Tag$ = [3, n0, _T,
    0,
    [_k, _v],
    [0, 0], 2
];
var TokenUsage$ = [3, n0, _TU,
    0,
    [_iT, _oT, _tT, _cRIT, _cWIT, _cD],
    [1, 1, 1, 1, 1, () => CacheDetailsList], 3
];
var ToolConfiguration$ = [3, n0, _TC,
    0,
    [_too, _tCo],
    [() => Tools, () => ToolChoice$], 1
];
var ToolResultBlock$ = [3, n0, _TRB,
    0,
    [_tUI, _co, _st, _ty],
    [0, [() => ToolResultContentBlocks, 0], 0, 0], 2
];
var ToolResultBlockStart$ = [3, n0, _TRBS,
    0,
    [_tUI, _ty, _st],
    [0, 0, 0], 1
];
var ToolSpecification$ = [3, n0, _TS,
    0,
    [_n, _iS, _des, _stri],
    [0, () => ToolInputSchema$, 0, 2], 2
];
var ToolUseBlock$ = [3, n0, _TUB,
    0,
    [_tUI, _n, _i, _ty],
    [0, 0, 15, 0], 3
];
var ToolUseBlockDelta$ = [3, n0, _TUBD,
    0,
    [_i],
    [0], 1
];
var ToolUseBlockStart$ = [3, n0, _TUBS,
    0,
    [_tUI, _n, _ty],
    [0, 0, 0], 2
];
var VideoBlock$ = [3, n0, _VB,
    0,
    [_f, _so],
    [0, () => VideoSource$], 2
];
var WebLocation$ = [3, n0, _WL,
    0,
    [_url, _do],
    [0, 0]
];
var AsyncInvokeSummaries = [1, n0, _AISs,
    0, [() => AsyncInvokeSummary$,
        0]
];
var CacheDetailsList = [1, n0, _CDL,
    0, () => CacheDetail$
];
var CitationGeneratedContentList = [1, n0, _CGCL,
    0, () => CitationGeneratedContent$
];
var Citations = [1, n0, _Ci,
    0, () => Citation$
];
var CitationSourceContentList = [1, n0, _CSCL,
    0, () => CitationSourceContent$
];
var CitationSourceContentListDelta = [1, n0, _CSCLD,
    0, () => CitationSourceContentDelta$
];
var ContentBlocks = [1, n0, _CB,
    0, [() => ContentBlock$,
        0]
];
var DocumentContentBlocks = [1, n0, _DCB,
    0, () => DocumentContentBlock$
];
var GuardrailAssessmentList = [1, n0, _GAL,
    0, [() => GuardrailAssessment$,
        0]
];
var GuardrailAutomatedReasoningDifferenceScenarioList = [1, n0, _GARDSL,
    0, [() => GuardrailAutomatedReasoningScenario$,
        0]
];
var GuardrailAutomatedReasoningFindingList = [1, n0, _GARFL,
    0, [() => GuardrailAutomatedReasoningFinding$,
        0]
];
var GuardrailAutomatedReasoningInputTextReferenceList = [1, n0, _GARITRL,
    0, [() => GuardrailAutomatedReasoningInputTextReference$,
        0]
];
var GuardrailAutomatedReasoningRuleList = [1, n0, _GARRL,
    0, () => GuardrailAutomatedReasoningRule$
];
var GuardrailAutomatedReasoningStatementList = [1, n0, _GARSL,
    0, [() => GuardrailAutomatedReasoningStatement$,
        0]
];
var GuardrailAutomatedReasoningTranslationList = [1, n0, _GARTL,
    0, [() => GuardrailAutomatedReasoningTranslation$,
        0]
];
var GuardrailAutomatedReasoningTranslationOptionList = [1, n0, _GARTOL,
    0, [() => GuardrailAutomatedReasoningTranslationOption$,
        0]
];
var GuardrailChecksContentBlockList = [1, n0, _GCCBL,
    0, [() => GuardrailChecksContentBlock$,
        0]
];
var GuardrailChecksContentFilterCategoryConfigList = [1, n0, _GCCFCCL,
    0, () => GuardrailChecksContentFilterCategoryConfig$
];
var GuardrailChecksContentFilterResultList = [1, n0, _GCCFRL,
    0, () => GuardrailChecksContentFilterResultEntry$
];
var GuardrailChecksMessageList = [1, n0, _GCML,
    0, [() => GuardrailChecksMessage$,
        0]
];
var GuardrailChecksPromptAttackCategoryConfigList = [1, n0, _GCPACCL,
    0, () => GuardrailChecksPromptAttackCategoryConfig$
];
var GuardrailChecksPromptAttackResultList = [1, n0, _GCPARL,
    0, () => GuardrailChecksPromptAttackResultEntry$
];
var GuardrailChecksSensitiveInformationEntityConfigList = [1, n0, _GCSIECL,
    0, () => GuardrailChecksSensitiveInformationEntityConfig$
];
var GuardrailChecksSensitiveInformationResultList = [1, n0, _GCSIRL,
    0, () => GuardrailChecksSensitiveInformationResultEntry$
];
var GuardrailContentBlockList = [1, n0, _GCBL,
    0, [() => GuardrailContentBlock$,
        0]
];
var GuardrailContentFilterList = [1, n0, _GCFL,
    0, () => GuardrailContentFilter$
];
var GuardrailContextualGroundingFilters = [1, n0, _GCGFu,
    0, () => GuardrailContextualGroundingFilter$
];
var GuardrailCustomWordList = [1, n0, _GCWL,
    0, () => GuardrailCustomWord$
];
var GuardrailManagedWordList = [1, n0, _GMWL,
    0, () => GuardrailManagedWord$
];
var GuardrailOutputContentList = [1, n0, _GOCL,
    0, () => GuardrailOutputContent$
];
var GuardrailPiiEntityFilterList = [1, n0, _GPEFL,
    0, () => GuardrailPiiEntityFilter$
];
var GuardrailRegexFilterList = [1, n0, _GRFL,
    0, () => GuardrailRegexFilter$
];
var GuardrailTopicList = [1, n0, _GTL,
    0, () => GuardrailTopic$
];
var Messages = [1, n0, _Me,
    0, [() => Message$,
        0]
];
var SearchResultContentBlocks = [1, n0, _SRCBe,
    0, () => SearchResultContentBlock$
];
var SystemContentBlocks = [1, n0, _SCB,
    0, [() => SystemContentBlock$,
        0]
];
var TagList = [1, n0, _TL,
    0, () => Tag$
];
var ToolResultBlocksDelta = [1, n0, _TRBD,
    0, () => ToolResultBlockDelta$
];
var ToolResultContentBlocks = [1, n0, _TRCB,
    0, [() => ToolResultContentBlock$,
        0]
];
var Tools = [1, n0, _To,
    0, () => Tool$
];
var GuardrailAssessmentListMap = [2, n0, _GALM,
    0, [0,
        0],
    [() => GuardrailAssessmentList,
        0]
];
var GuardrailAssessmentMap = [2, n0, _GAM,
    0, [0,
        0],
    [() => GuardrailAssessment$,
        0]
];
var PromptVariableMap = [2, n0, _PVM,
    8, 0, () => PromptVariableValues$
];
var RequestMetadata = [2, n0, _RM,
    8, 0, 0
];
var AsyncInvokeOutputDataConfig$ = [4, n0, _AIODC,
    0,
    [_sODC],
    [() => AsyncInvokeS3OutputDataConfig$]
];
var AudioSource$ = [4, n0, _AS,
    8,
    [_b, _sL],
    [21, () => S3Location$]
];
var CitationGeneratedContent$ = [4, n0, _CGC,
    0,
    [_te],
    [0]
];
var CitationLocation$ = [4, n0, _CL,
    0,
    [_w, _dC, _dP, _dCo, _sRL],
    [() => WebLocation$, () => DocumentCharLocation$, () => DocumentPageLocation$, () => DocumentChunkLocation$, () => SearchResultLocation$]
];
var CitationSourceContent$ = [4, n0, _CSC,
    0,
    [_te],
    [0]
];
var ContentBlock$ = [4, n0, _CBo,
    0,
    [_te, _ima, _doc, _vi, _au, _tUo, _tR, _gCua, _cPa, _rC, _cC, _sRe],
    [0, [() => ImageBlock$, 0], () => DocumentBlock$, () => VideoBlock$, [() => AudioBlock$, 0], () => ToolUseBlock$, [() => ToolResultBlock$, 0], [() => GuardrailConverseContentBlock$, 0], () => CachePointBlock$, [() => ReasoningContentBlock$, 0], () => CitationsContentBlock$, () => SearchResultBlock$]
];
var ContentBlockDelta$ = [4, n0, _CBD,
    0,
    [_te, _tUo, _tR, _rC, _cit, _ima],
    [0, () => ToolUseBlockDelta$, () => ToolResultBlocksDelta, [() => ReasoningContentBlockDelta$, 0], () => CitationsDelta$, [() => ImageBlockDelta$, 0]]
];
var ContentBlockStart$ = [4, n0, _CBS,
    0,
    [_tUo, _tR, _ima],
    [() => ToolUseBlockStart$, () => ToolResultBlockStart$, () => ImageBlockStart$]
];
var ConverseOutput$ = [4, n0, _CO,
    0,
    [_m],
    [[() => Message$, 0]]
];
var ConverseStreamOutput$ = [4, n0, _CSO,
    { [_stre]: 1 },
    [_mS, _cBS, _cBD, _cBSo, _mSe, _meta, _iSE, _mSEE, _vE, _tE, _sUE],
    [() => MessageStartEvent$, () => ContentBlockStartEvent$, [() => ContentBlockDeltaEvent$, 0], () => ContentBlockStopEvent$, () => MessageStopEvent$, [() => ConverseStreamMetadataEvent$, 0], [() => InternalServerException$, 0], [() => ModelStreamErrorException$, 0], [() => ValidationException$, 0], [() => ThrottlingException$, 0], [() => ServiceUnavailableException$, 0]]
];
var CountTokensInput$ = [4, n0, _CTI,
    0,
    [_iMn, _conv],
    [[() => InvokeModelTokensRequest$, 0], [() => ConverseTokensRequest$, 0]]
];
var DocumentContentBlock$ = [4, n0, _DCBo,
    0,
    [_te],
    [0]
];
var DocumentSource$ = [4, n0, _DS,
    0,
    [_b, _sL, _te, _co],
    [21, () => S3Location$, 0, () => DocumentContentBlocks]
];
var GuardrailAutomatedReasoningFinding$ = [4, n0, _GARF,
    0,
    [_va, _in, _sa, _imp, _tA, _tCoo, _nTo],
    [[() => GuardrailAutomatedReasoningValidFinding$, 0], [() => GuardrailAutomatedReasoningInvalidFinding$, 0], [() => GuardrailAutomatedReasoningSatisfiableFinding$, 0], [() => GuardrailAutomatedReasoningImpossibleFinding$, 0], [() => GuardrailAutomatedReasoningTranslationAmbiguousFinding$, 0], () => GuardrailAutomatedReasoningTooComplexFinding$, () => GuardrailAutomatedReasoningNoTranslationsFinding$]
];
var GuardrailChecksContentBlock$ = [4, n0, _GCCB,
    0,
    [_te],
    [[() => GuardrailChecksTextContent, 0]]
];
var GuardrailContentBlock$ = [4, n0, _GCB,
    0,
    [_te, _ima],
    [() => GuardrailTextBlock$, [() => GuardrailImageBlock$, 0]]
];
var GuardrailConverseContentBlock$ = [4, n0, _GCCBu,
    0,
    [_te, _ima],
    [() => GuardrailConverseTextBlock$, [() => GuardrailConverseImageBlock$, 0]]
];
var GuardrailConverseImageSource$ = [4, n0, _GCIS,
    8,
    [_b],
    [21]
];
var GuardrailImageSource$ = [4, n0, _GIS,
    8,
    [_b],
    [21]
];
var ImageSource$ = [4, n0, _IS,
    8,
    [_b, _sL],
    [21, () => S3Location$]
];
var InvokeModelWithBidirectionalStreamInput$ = [4, n0, _IMWBSI,
    { [_stre]: 1 },
    [_chu],
    [[() => BidirectionalInputPayloadPart$, 0]]
];
var InvokeModelWithBidirectionalStreamOutput$ = [4, n0, _IMWBSO,
    { [_stre]: 1 },
    [_chu, _iSE, _mSEE, _vE, _tE, _mTE, _sUE],
    [[() => BidirectionalOutputPayloadPart$, 0], [() => InternalServerException$, 0], [() => ModelStreamErrorException$, 0], [() => ValidationException$, 0], [() => ThrottlingException$, 0], [() => ModelTimeoutException$, 0], [() => ServiceUnavailableException$, 0]]
];
var OutputFormatStructure$ = [4, n0, _OFS,
    8,
    [_jS],
    [() => JsonSchemaDefinition$]
];
var PromptVariableValues$ = [4, n0, _PVV,
    0,
    [_te],
    [0]
];
var ReasoningContentBlock$ = [4, n0, _RCB,
    8,
    [_rT, _rCe],
    [[() => ReasoningTextBlock$, 0], 21]
];
var ReasoningContentBlockDelta$ = [4, n0, _RCBD,
    8,
    [_te, _rCe, _si],
    [0, 21, 0]
];
var ResponseStream$ = [4, n0, _RS,
    { [_stre]: 1 },
    [_chu, _iSE, _mSEE, _vE, _tE, _mTE, _sUE],
    [[() => PayloadPart$, 0], [() => InternalServerException$, 0], [() => ModelStreamErrorException$, 0], [() => ValidationException$, 0], [() => ThrottlingException$, 0], [() => ModelTimeoutException$, 0], [() => ServiceUnavailableException$, 0]]
];
var SystemContentBlock$ = [4, n0, _SCBy,
    0,
    [_te, _gCua, _cPa],
    [0, [() => GuardrailConverseContentBlock$, 0], () => CachePointBlock$]
];
var Tool$ = [4, n0, _Too,
    0,
    [_tS, _sTy, _cPa],
    [() => ToolSpecification$, () => SystemTool$, () => CachePointBlock$]
];
var ToolChoice$ = [4, n0, _TCo,
    0,
    [_aut, _an, _tool],
    [() => AutoToolChoice$, () => AnyToolChoice$, () => SpecificToolChoice$]
];
var ToolInputSchema$ = [4, n0, _TIS,
    0,
    [_j],
    [15]
];
var ToolResultBlockDelta$ = [4, n0, _TRBDo,
    0,
    [_te, _j],
    [0, 15]
];
var ToolResultContentBlock$ = [4, n0, _TRCBo,
    0,
    [_j, _te, _ima, _doc, _vi, _sRe],
    [15, 0, [() => ImageBlock$, 0], () => DocumentBlock$, () => VideoBlock$, () => SearchResultBlock$]
];
var VideoSource$ = [4, n0, _VS,
    0,
    [_b, _sL],
    [21, () => S3Location$]
];
var ApplyGuardrail$ = [9, n0, _AG,
    { [_h]: ["POST", "/guardrail/{guardrailIdentifier}/version/{guardrailVersion}/apply", 200] }, () => ApplyGuardrailRequest$, () => ApplyGuardrailResponse$
];
var Converse$ = [9, n0, _Co,
    { [_h]: ["POST", "/model/{modelId}/converse", 200] }, () => ConverseRequest$, () => ConverseResponse$
];
var ConverseStream$ = [9, n0, _CS,
    { [_h]: ["POST", "/model/{modelId}/converse-stream", 200] }, () => ConverseStreamRequest$, () => ConverseStreamResponse$
];
var CountTokens$ = [9, n0, _CTo,
    { [_h]: ["POST", "/model/{modelId}/count-tokens", 200] }, () => CountTokensRequest$, () => CountTokensResponse$
];
var GetAsyncInvoke$ = [9, n0, _GAI,
    { [_h]: ["GET", "/async-invoke/{invocationArn}", 200] }, () => GetAsyncInvokeRequest$, () => GetAsyncInvokeResponse$
];
var InvokeGuardrailChecks$ = [9, n0, _IGC,
    { [_h]: ["POST", "/guardrail-checks/invoke", 200] }, () => InvokeGuardrailChecksRequest$, () => InvokeGuardrailChecksResponse$
];
var InvokeModel$ = [9, n0, _IM,
    { [_h]: ["POST", "/model/{modelId}/invoke", 200] }, () => InvokeModelRequest$, () => InvokeModelResponse$
];
var InvokeModelWithBidirectionalStream$ = [9, n0, _IMWBS,
    { [_h]: ["POST", "/model/{modelId}/invoke-with-bidirectional-stream", 200] }, () => InvokeModelWithBidirectionalStreamRequest$, () => InvokeModelWithBidirectionalStreamResponse$
];
var InvokeModelWithResponseStream$ = [9, n0, _IMWRS,
    { [_h]: ["POST", "/model/{modelId}/invoke-with-response-stream", 200] }, () => InvokeModelWithResponseStreamRequest$, () => InvokeModelWithResponseStreamResponse$
];
var ListAsyncInvokes$ = [9, n0, _LAI,
    { [_h]: ["GET", "/async-invoke", 200] }, () => ListAsyncInvokesRequest$, () => ListAsyncInvokesResponse$
];
var StartAsyncInvoke$ = [9, n0, _SAI,
    { [_h]: ["POST", "/async-invoke", 200] }, () => StartAsyncInvokeRequest$, () => StartAsyncInvokeResponse$
];

const getRuntimeConfig$1 = (config) => {
    return {
        apiVersion: "2023-09-30",
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        disableHostPrefix: config?.disableHostPrefix ?? false,
        endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
        extensions: config?.extensions ?? [],
        httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultBedrockRuntimeHttpAuthSchemeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new AwsSdkSigV4Signer(),
            },
            {
                schemeId: "smithy.api#httpBearerAuth",
                identityProvider: (ipc) => ipc.getIdentityProvider("smithy.api#httpBearerAuth"),
                signer: new HttpBearerAuthSigner(),
            },
        ],
        logger: config?.logger ?? new NoOpLogger(),
        protocol: config?.protocol ?? AwsRestJsonProtocol,
        protocolSettings: config?.protocolSettings ?? {
            defaultNamespace: "com.amazonaws.bedrockruntime",
            errorTypeRegistries,
            version: "2023-09-30",
            serviceTarget: "AmazonBedrockFrontendService",
        },
        serviceId: config?.serviceId ?? "Bedrock Runtime",
        sha256: config?.sha256 ?? Sha256,
        urlParser: config?.urlParser ?? parseUrl,
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

const getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = getRuntimeConfig$1(config);
    emitWarningIfUnsupportedVersion$1(process.version);
    const loaderConfig = {
        profile: config?.profile,
        logger: clientSharedValues.logger,
        signingName: "bedrock",
    };
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        authSchemePreference: config?.authSchemePreference ?? loadConfig(NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
        defaultUserAgentProvider: config?.defaultUserAgentProvider ?? createDefaultUserAgentProvider({ serviceId: clientSharedValues.serviceId, clientVersion: packageInfo.version }),
        eventStreamPayloadHandlerProvider: config?.eventStreamPayloadHandlerProvider ?? eventStreamPayloadHandlerProvider,
        eventStreamSerdeProvider: config?.eventStreamSerdeProvider ?? eventStreamSerdeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new AwsSdkSigV4Signer(),
            },
            {
                schemeId: "smithy.api#httpBearerAuth",
                identityProvider: (ipc) => ipc.getIdentityProvider("smithy.api#httpBearerAuth") || (async (idProps) => {
                    try {
                        return await fromEnvSigningName({ signingName: "bedrock" })();
                    }
                    catch (error) {
                        return await nodeProvider(idProps)(idProps);
                    }
                }),
                signer: new HttpBearerAuthSigner(),
            },
        ],
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, { ...NODE_REGION_CONFIG_FILE_OPTIONS, ...loaderConfig }),
        requestHandler: NodeHttp2Handler.create(config?.requestHandler ?? (async () => ({
            ...await defaultConfigProvider(),
            disableConcurrentStreams: true
        }))),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }, config),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        userAgentAppId: config?.userAgentAppId ?? loadConfig(NODE_APP_ID_CONFIG_OPTIONS, loaderConfig),
    };
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    let _token = runtimeConfig.token;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
        setToken(token) {
            _token = token;
        },
        token() {
            return _token;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
        token: config.token(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(getAwsRegionExtensionConfiguration(runtimeConfig), getDefaultExtensionConfiguration(runtimeConfig), getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, resolveAwsRegionExtensionConfiguration(extensionConfiguration), resolveDefaultRuntimeConfig(extensionConfiguration), resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class BedrockRuntimeClient extends Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = resolveUserAgentConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveRegionConfig(_config_3);
        const _config_5 = resolveHostHeaderConfig(_config_4);
        const _config_6 = resolveEndpointConfig(_config_5);
        const _config_7 = resolveEventStreamSerdeConfig(_config_6);
        const _config_8 = resolveHttpAuthSchemeConfig(_config_7);
        const _config_9 = resolveEventStreamConfig(_config_8);
        const _config_10 = resolveWebSocketConfig(_config_9);
        const _config_11 = resolveRuntimeExtensions(_config_10, configuration?.extensions || []);
        this.config = _config_11;
        this.middlewareStack.use(getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: defaultBedrockRuntimeHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
                "smithy.api#httpBearerAuth": config.token,
            }),
        }));
        this.middlewareStack.use(getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

const command = makeBuilder(commonParams, "AmazonBedrockFrontendService", "BedrockRuntimeClient", getEndpointPlugin);
const _ep0 = {};
const _mw0 = (Command, cs, config, o) => [];
const _mw1 = (Command, cs, config, o) => [
    getEventStreamPlugin(config),
    getWebSocketPlugin(config, {
        headerPrefix: "x-amz-bedrock-",
    }),
];

class ApplyGuardrailCommand extends command(_ep0, _mw0, "ApplyGuardrail", ApplyGuardrail$) {
}

class ConverseCommand extends command(_ep0, _mw0, "Converse", Converse$) {
}

class ConverseStreamCommand extends command(_ep0, _mw0, "ConverseStream", ConverseStream$) {
}

class CountTokensCommand extends command(_ep0, _mw0, "CountTokens", CountTokens$) {
}

class GetAsyncInvokeCommand extends command(_ep0, _mw0, "GetAsyncInvoke", GetAsyncInvoke$) {
}

class InvokeGuardrailChecksCommand extends command(_ep0, _mw0, "InvokeGuardrailChecks", InvokeGuardrailChecks$) {
}

class InvokeModelCommand extends command(_ep0, _mw0, "InvokeModel", InvokeModel$) {
}

class InvokeModelWithBidirectionalStreamCommand extends command(_ep0, _mw1, "InvokeModelWithBidirectionalStream", InvokeModelWithBidirectionalStream$) {
}

class InvokeModelWithResponseStreamCommand extends command(_ep0, _mw0, "InvokeModelWithResponseStream", InvokeModelWithResponseStream$) {
}

class ListAsyncInvokesCommand extends command(_ep0, _mw0, "ListAsyncInvokes", ListAsyncInvokes$) {
}

class StartAsyncInvokeCommand extends command(_ep0, _mw0, "StartAsyncInvoke", StartAsyncInvoke$) {
}

const paginateListAsyncInvokes = createPaginator(BedrockRuntimeClient, ListAsyncInvokesCommand, "nextToken", "nextToken", "maxResults");

const commands = {
    ApplyGuardrailCommand,
    ConverseCommand,
    ConverseStreamCommand,
    CountTokensCommand,
    GetAsyncInvokeCommand,
    InvokeGuardrailChecksCommand,
    InvokeModelCommand,
    InvokeModelWithBidirectionalStreamCommand,
    InvokeModelWithResponseStreamCommand,
    ListAsyncInvokesCommand,
    StartAsyncInvokeCommand,
};
const paginators = {
    paginateListAsyncInvokes,
};
class BedrockRuntime extends BedrockRuntimeClient {
}
createAggregatedClient(commands, BedrockRuntime, { paginators });

const AsyncInvokeStatus = {
    COMPLETED: "Completed",
    FAILED: "Failed",
    IN_PROGRESS: "InProgress",
};
const SortAsyncInvocationBy = {
    SUBMISSION_TIME: "SubmissionTime",
};
const SortOrder = {
    ASCENDING: "Ascending",
    DESCENDING: "Descending",
};
const GuardrailImageFormat = {
    JPEG: "jpeg",
    PNG: "png",
};
const GuardrailContentQualifier = {
    GROUNDING_SOURCE: "grounding_source",
    GUARD_CONTENT: "guard_content",
    QUERY: "query",
};
const GuardrailOutputScope = {
    FULL: "FULL",
    INTERVENTIONS: "INTERVENTIONS",
};
const GuardrailContentSource = {
    INPUT: "INPUT",
    OUTPUT: "OUTPUT",
};
const GuardrailAction = {
    GUARDRAIL_INTERVENED: "GUARDRAIL_INTERVENED",
    NONE: "NONE",
};
const GuardrailOrigin = {
    ACCOUNT_ENFORCED: "ACCOUNT_ENFORCED",
    ORGANIZATION_ENFORCED: "ORGANIZATION_ENFORCED",
    REQUEST: "REQUEST",
};
const GuardrailOwnership = {
    CROSS_ACCOUNT: "CROSS_ACCOUNT",
    SELF: "SELF",
};
const GuardrailAutomatedReasoningLogicWarningType = {
    ALWAYS_FALSE: "ALWAYS_FALSE",
    ALWAYS_TRUE: "ALWAYS_TRUE",
};
const GuardrailContentPolicyAction = {
    BLOCKED: "BLOCKED",
    NONE: "NONE",
};
const GuardrailContentFilterConfidence = {
    HIGH: "HIGH",
    LOW: "LOW",
    MEDIUM: "MEDIUM",
    NONE: "NONE",
};
const GuardrailContentFilterStrength = {
    HIGH: "HIGH",
    LOW: "LOW",
    MEDIUM: "MEDIUM",
    NONE: "NONE",
};
const GuardrailContentFilterType = {
    HATE: "HATE",
    INSULTS: "INSULTS",
    MISCONDUCT: "MISCONDUCT",
    PROMPT_ATTACK: "PROMPT_ATTACK",
    SEXUAL: "SEXUAL",
    VIOLENCE: "VIOLENCE",
};
const GuardrailContextualGroundingPolicyAction = {
    BLOCKED: "BLOCKED",
    NONE: "NONE",
};
const GuardrailContextualGroundingFilterType = {
    GROUNDING: "GROUNDING",
    RELEVANCE: "RELEVANCE",
};
const GuardrailSensitiveInformationPolicyAction = {
    ANONYMIZED: "ANONYMIZED",
    BLOCKED: "BLOCKED",
    NONE: "NONE",
};
const GuardrailPiiEntityType = {
    ADDRESS: "ADDRESS",
    AGE: "AGE",
    AWS_ACCESS_KEY: "AWS_ACCESS_KEY",
    AWS_SECRET_KEY: "AWS_SECRET_KEY",
    CA_HEALTH_NUMBER: "CA_HEALTH_NUMBER",
    CA_SOCIAL_INSURANCE_NUMBER: "CA_SOCIAL_INSURANCE_NUMBER",
    CREDIT_DEBIT_CARD_CVV: "CREDIT_DEBIT_CARD_CVV",
    CREDIT_DEBIT_CARD_EXPIRY: "CREDIT_DEBIT_CARD_EXPIRY",
    CREDIT_DEBIT_CARD_NUMBER: "CREDIT_DEBIT_CARD_NUMBER",
    DRIVER_ID: "DRIVER_ID",
    EMAIL: "EMAIL",
    INTERNATIONAL_BANK_ACCOUNT_NUMBER: "INTERNATIONAL_BANK_ACCOUNT_NUMBER",
    IP_ADDRESS: "IP_ADDRESS",
    LICENSE_PLATE: "LICENSE_PLATE",
    MAC_ADDRESS: "MAC_ADDRESS",
    NAME: "NAME",
    PASSWORD: "PASSWORD",
    PHONE: "PHONE",
    PIN: "PIN",
    SWIFT_CODE: "SWIFT_CODE",
    UK_NATIONAL_HEALTH_SERVICE_NUMBER: "UK_NATIONAL_HEALTH_SERVICE_NUMBER",
    UK_NATIONAL_INSURANCE_NUMBER: "UK_NATIONAL_INSURANCE_NUMBER",
    UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER: "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER",
    URL: "URL",
    USERNAME: "USERNAME",
    US_BANK_ACCOUNT_NUMBER: "US_BANK_ACCOUNT_NUMBER",
    US_BANK_ROUTING_NUMBER: "US_BANK_ROUTING_NUMBER",
    US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER: "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER",
    US_PASSPORT_NUMBER: "US_PASSPORT_NUMBER",
    US_SOCIAL_SECURITY_NUMBER: "US_SOCIAL_SECURITY_NUMBER",
    VEHICLE_IDENTIFICATION_NUMBER: "VEHICLE_IDENTIFICATION_NUMBER",
};
const GuardrailTopicPolicyAction = {
    BLOCKED: "BLOCKED",
    NONE: "NONE",
};
const GuardrailTopicType = {
    DENY: "DENY",
};
const GuardrailWordPolicyAction = {
    BLOCKED: "BLOCKED",
    NONE: "NONE",
};
const GuardrailManagedWordType = {
    PROFANITY: "PROFANITY",
};
const GuardrailChecksContentFilterCategory = {
    HATE: "HATE",
    INSULTS: "INSULTS",
    MISCONDUCT: "MISCONDUCT",
    SEXUAL: "SEXUAL",
    VIOLENCE: "VIOLENCE",
};
const GuardrailChecksPromptAttackCategory = {
    JAILBREAK: "JAILBREAK",
    PROMPT_INJECTION: "PROMPT_INJECTION",
    PROMPT_LEAKAGE: "PROMPT_LEAKAGE",
};
const GuardrailChecksSensitiveInformationEntityType = {
    ADDRESS: "ADDRESS",
    AGE: "AGE",
    AWS_ACCESS_KEY: "AWS_ACCESS_KEY",
    AWS_SECRET_KEY: "AWS_SECRET_KEY",
    CA_HEALTH_NUMBER: "CA_HEALTH_NUMBER",
    CA_SOCIAL_INSURANCE_NUMBER: "CA_SOCIAL_INSURANCE_NUMBER",
    CREDIT_DEBIT_CARD_CVV: "CREDIT_DEBIT_CARD_CVV",
    CREDIT_DEBIT_CARD_EXPIRY: "CREDIT_DEBIT_CARD_EXPIRY",
    CREDIT_DEBIT_CARD_NUMBER: "CREDIT_DEBIT_CARD_NUMBER",
    DRIVER_ID: "DRIVER_ID",
    EMAIL: "EMAIL",
    INTERNATIONAL_BANK_ACCOUNT_NUMBER: "INTERNATIONAL_BANK_ACCOUNT_NUMBER",
    IP_ADDRESS: "IP_ADDRESS",
    LICENSE_PLATE: "LICENSE_PLATE",
    MAC_ADDRESS: "MAC_ADDRESS",
    NAME: "NAME",
    PASSWORD: "PASSWORD",
    PHONE: "PHONE",
    PIN: "PIN",
    SWIFT_CODE: "SWIFT_CODE",
    UK_NATIONAL_HEALTH_SERVICE_NUMBER: "UK_NATIONAL_HEALTH_SERVICE_NUMBER",
    UK_NATIONAL_INSURANCE_NUMBER: "UK_NATIONAL_INSURANCE_NUMBER",
    UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER: "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER",
    URL: "URL",
    USERNAME: "USERNAME",
    US_BANK_ACCOUNT_NUMBER: "US_BANK_ACCOUNT_NUMBER",
    US_BANK_ROUTING_NUMBER: "US_BANK_ROUTING_NUMBER",
    US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER: "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER",
    US_PASSPORT_NUMBER: "US_PASSPORT_NUMBER",
    US_SOCIAL_SECURITY_NUMBER: "US_SOCIAL_SECURITY_NUMBER",
    VEHICLE_IDENTIFICATION_NUMBER: "VEHICLE_IDENTIFICATION_NUMBER",
};
const GuardrailChecksRole = {
    ASSISTANT: "assistant",
    SYSTEM: "system",
    USER: "user",
};
const GuardrailTrace = {
    DISABLED: "disabled",
    ENABLED: "enabled",
    ENABLED_FULL: "enabled_full",
};
const AudioFormat = {
    AAC: "aac",
    FLAC: "flac",
    M4A: "m4a",
    MKA: "mka",
    MKV: "mkv",
    MP3: "mp3",
    MP4: "mp4",
    MPEG: "mpeg",
    MPGA: "mpga",
    OGG: "ogg",
    OPUS: "opus",
    PCM: "pcm",
    WAV: "wav",
    WEBM: "webm",
    X_AAC: "x-aac",
};
const CacheTTL = {
    FIVE_MINUTES: "5m",
    ONE_HOUR: "1h",
};
const CachePointType = {
    DEFAULT: "default",
};
const DocumentFormat = {
    CSV: "csv",
    DOC: "doc",
    DOCX: "docx",
    HTML: "html",
    MD: "md",
    PDF: "pdf",
    TXT: "txt",
    XLS: "xls",
    XLSX: "xlsx",
};
const GuardrailConverseImageFormat = {
    JPEG: "jpeg",
    PNG: "png",
};
const GuardrailConverseContentQualifier = {
    GROUNDING_SOURCE: "grounding_source",
    GUARD_CONTENT: "guard_content",
    QUERY: "query",
};
const ImageFormat = {
    GIF: "gif",
    JPEG: "jpeg",
    PNG: "png",
    WEBP: "webp",
};
const VideoFormat = {
    FLV: "flv",
    MKV: "mkv",
    MOV: "mov",
    MP4: "mp4",
    MPEG: "mpeg",
    MPG: "mpg",
    THREE_GP: "three_gp",
    WEBM: "webm",
    WMV: "wmv",
};
const ToolResultStatus = {
    ERROR: "error",
    SUCCESS: "success",
};
const ToolUseType = {
    SERVER_TOOL_USE: "server_tool_use",
};
const ConversationRole = {
    ASSISTANT: "assistant",
    SYSTEM: "system",
    USER: "user",
};
const OutputFormatType = {
    JSON_SCHEMA: "json_schema",
};
const PerformanceConfigLatency = {
    OPTIMIZED: "optimized",
    STANDARD: "standard",
};
const ServiceTierType = {
    DEFAULT: "default",
    FLEX: "flex",
    PRIORITY: "priority",
    RESERVED: "reserved",
};
const StopReason = {
    CONTENT_FILTERED: "content_filtered",
    END_TURN: "end_turn",
    GUARDRAIL_INTERVENED: "guardrail_intervened",
    MALFORMED_MODEL_OUTPUT: "malformed_model_output",
    MALFORMED_TOOL_USE: "malformed_tool_use",
    MAX_TOKENS: "max_tokens",
    MODEL_CONTEXT_WINDOW_EXCEEDED: "model_context_window_exceeded",
    STOP_SEQUENCE: "stop_sequence",
    TOOL_USE: "tool_use",
};
const GuardrailStreamProcessingMode = {
    ASYNC: "async",
    SYNC: "sync",
};
const Trace = {
    DISABLED: "DISABLED",
    ENABLED: "ENABLED",
    ENABLED_FULL: "ENABLED_FULL",
};

exports.AccessDeniedException = AccessDeniedException;
exports.AccessDeniedException$ = AccessDeniedException$;
exports.AnyToolChoice$ = AnyToolChoice$;
exports.AppliedGuardrailDetails$ = AppliedGuardrailDetails$;
exports.ApplyGuardrail$ = ApplyGuardrail$;
exports.ApplyGuardrailCommand = ApplyGuardrailCommand;
exports.ApplyGuardrailRequest$ = ApplyGuardrailRequest$;
exports.ApplyGuardrailResponse$ = ApplyGuardrailResponse$;
exports.AsyncInvokeOutputDataConfig$ = AsyncInvokeOutputDataConfig$;
exports.AsyncInvokeS3OutputDataConfig$ = AsyncInvokeS3OutputDataConfig$;
exports.AsyncInvokeStatus = AsyncInvokeStatus;
exports.AsyncInvokeSummary$ = AsyncInvokeSummary$;
exports.AudioBlock$ = AudioBlock$;
exports.AudioFormat = AudioFormat;
exports.AudioSource$ = AudioSource$;
exports.AutoToolChoice$ = AutoToolChoice$;
exports.BedrockRuntime = BedrockRuntime;
exports.BedrockRuntimeClient = BedrockRuntimeClient;
exports.BedrockRuntimeServiceException = BedrockRuntimeServiceException;
exports.BedrockRuntimeServiceException$ = BedrockRuntimeServiceException$;
exports.BidirectionalInputPayloadPart$ = BidirectionalInputPayloadPart$;
exports.BidirectionalOutputPayloadPart$ = BidirectionalOutputPayloadPart$;
exports.CacheDetail$ = CacheDetail$;
exports.CachePointBlock$ = CachePointBlock$;
exports.CachePointType = CachePointType;
exports.CacheTTL = CacheTTL;
exports.Citation$ = Citation$;
exports.CitationGeneratedContent$ = CitationGeneratedContent$;
exports.CitationLocation$ = CitationLocation$;
exports.CitationSourceContent$ = CitationSourceContent$;
exports.CitationSourceContentDelta$ = CitationSourceContentDelta$;
exports.CitationsConfig$ = CitationsConfig$;
exports.CitationsContentBlock$ = CitationsContentBlock$;
exports.CitationsDelta$ = CitationsDelta$;
exports.ConflictException = ConflictException;
exports.ConflictException$ = ConflictException$;
exports.ContentBlock$ = ContentBlock$;
exports.ContentBlockDelta$ = ContentBlockDelta$;
exports.ContentBlockDeltaEvent$ = ContentBlockDeltaEvent$;
exports.ContentBlockStart$ = ContentBlockStart$;
exports.ContentBlockStartEvent$ = ContentBlockStartEvent$;
exports.ContentBlockStopEvent$ = ContentBlockStopEvent$;
exports.ConversationRole = ConversationRole;
exports.Converse$ = Converse$;
exports.ConverseCommand = ConverseCommand;
exports.ConverseMetrics$ = ConverseMetrics$;
exports.ConverseOutput$ = ConverseOutput$;
exports.ConverseRequest$ = ConverseRequest$;
exports.ConverseResponse$ = ConverseResponse$;
exports.ConverseStream$ = ConverseStream$;
exports.ConverseStreamCommand = ConverseStreamCommand;
exports.ConverseStreamMetadataEvent$ = ConverseStreamMetadataEvent$;
exports.ConverseStreamMetrics$ = ConverseStreamMetrics$;
exports.ConverseStreamOutput$ = ConverseStreamOutput$;
exports.ConverseStreamRequest$ = ConverseStreamRequest$;
exports.ConverseStreamResponse$ = ConverseStreamResponse$;
exports.ConverseStreamTrace$ = ConverseStreamTrace$;
exports.ConverseTokensRequest$ = ConverseTokensRequest$;
exports.ConverseTrace$ = ConverseTrace$;
exports.CountTokens$ = CountTokens$;
exports.CountTokensCommand = CountTokensCommand;
exports.CountTokensInput$ = CountTokensInput$;
exports.CountTokensRequest$ = CountTokensRequest$;
exports.CountTokensResponse$ = CountTokensResponse$;
exports.DocumentBlock$ = DocumentBlock$;
exports.DocumentCharLocation$ = DocumentCharLocation$;
exports.DocumentChunkLocation$ = DocumentChunkLocation$;
exports.DocumentContentBlock$ = DocumentContentBlock$;
exports.DocumentFormat = DocumentFormat;
exports.DocumentPageLocation$ = DocumentPageLocation$;
exports.DocumentSource$ = DocumentSource$;
exports.ErrorBlock$ = ErrorBlock$;
exports.GetAsyncInvoke$ = GetAsyncInvoke$;
exports.GetAsyncInvokeCommand = GetAsyncInvokeCommand;
exports.GetAsyncInvokeRequest$ = GetAsyncInvokeRequest$;
exports.GetAsyncInvokeResponse$ = GetAsyncInvokeResponse$;
exports.GuardrailAction = GuardrailAction;
exports.GuardrailAssessment$ = GuardrailAssessment$;
exports.GuardrailAutomatedReasoningFinding$ = GuardrailAutomatedReasoningFinding$;
exports.GuardrailAutomatedReasoningImpossibleFinding$ = GuardrailAutomatedReasoningImpossibleFinding$;
exports.GuardrailAutomatedReasoningInputTextReference$ = GuardrailAutomatedReasoningInputTextReference$;
exports.GuardrailAutomatedReasoningInvalidFinding$ = GuardrailAutomatedReasoningInvalidFinding$;
exports.GuardrailAutomatedReasoningLogicWarning$ = GuardrailAutomatedReasoningLogicWarning$;
exports.GuardrailAutomatedReasoningLogicWarningType = GuardrailAutomatedReasoningLogicWarningType;
exports.GuardrailAutomatedReasoningNoTranslationsFinding$ = GuardrailAutomatedReasoningNoTranslationsFinding$;
exports.GuardrailAutomatedReasoningPolicyAssessment$ = GuardrailAutomatedReasoningPolicyAssessment$;
exports.GuardrailAutomatedReasoningRule$ = GuardrailAutomatedReasoningRule$;
exports.GuardrailAutomatedReasoningSatisfiableFinding$ = GuardrailAutomatedReasoningSatisfiableFinding$;
exports.GuardrailAutomatedReasoningScenario$ = GuardrailAutomatedReasoningScenario$;
exports.GuardrailAutomatedReasoningStatement$ = GuardrailAutomatedReasoningStatement$;
exports.GuardrailAutomatedReasoningTooComplexFinding$ = GuardrailAutomatedReasoningTooComplexFinding$;
exports.GuardrailAutomatedReasoningTranslation$ = GuardrailAutomatedReasoningTranslation$;
exports.GuardrailAutomatedReasoningTranslationAmbiguousFinding$ = GuardrailAutomatedReasoningTranslationAmbiguousFinding$;
exports.GuardrailAutomatedReasoningTranslationOption$ = GuardrailAutomatedReasoningTranslationOption$;
exports.GuardrailAutomatedReasoningValidFinding$ = GuardrailAutomatedReasoningValidFinding$;
exports.GuardrailChecksConfig$ = GuardrailChecksConfig$;
exports.GuardrailChecksContentBlock$ = GuardrailChecksContentBlock$;
exports.GuardrailChecksContentFilterCategory = GuardrailChecksContentFilterCategory;
exports.GuardrailChecksContentFilterCategoryConfig$ = GuardrailChecksContentFilterCategoryConfig$;
exports.GuardrailChecksContentFilterConfig$ = GuardrailChecksContentFilterConfig$;
exports.GuardrailChecksContentFilterResult$ = GuardrailChecksContentFilterResult$;
exports.GuardrailChecksContentFilterResultEntry$ = GuardrailChecksContentFilterResultEntry$;
exports.GuardrailChecksContentFilterUsage$ = GuardrailChecksContentFilterUsage$;
exports.GuardrailChecksMessage$ = GuardrailChecksMessage$;
exports.GuardrailChecksPromptAttackCategory = GuardrailChecksPromptAttackCategory;
exports.GuardrailChecksPromptAttackCategoryConfig$ = GuardrailChecksPromptAttackCategoryConfig$;
exports.GuardrailChecksPromptAttackConfig$ = GuardrailChecksPromptAttackConfig$;
exports.GuardrailChecksPromptAttackResult$ = GuardrailChecksPromptAttackResult$;
exports.GuardrailChecksPromptAttackResultEntry$ = GuardrailChecksPromptAttackResultEntry$;
exports.GuardrailChecksPromptAttackUsage$ = GuardrailChecksPromptAttackUsage$;
exports.GuardrailChecksResults$ = GuardrailChecksResults$;
exports.GuardrailChecksRole = GuardrailChecksRole;
exports.GuardrailChecksSensitiveInformationConfig$ = GuardrailChecksSensitiveInformationConfig$;
exports.GuardrailChecksSensitiveInformationEntityConfig$ = GuardrailChecksSensitiveInformationEntityConfig$;
exports.GuardrailChecksSensitiveInformationEntityType = GuardrailChecksSensitiveInformationEntityType;
exports.GuardrailChecksSensitiveInformationResult$ = GuardrailChecksSensitiveInformationResult$;
exports.GuardrailChecksSensitiveInformationResultEntry$ = GuardrailChecksSensitiveInformationResultEntry$;
exports.GuardrailChecksSensitiveInformationUsage$ = GuardrailChecksSensitiveInformationUsage$;
exports.GuardrailChecksUsageResults$ = GuardrailChecksUsageResults$;
exports.GuardrailConfiguration$ = GuardrailConfiguration$;
exports.GuardrailContentBlock$ = GuardrailContentBlock$;
exports.GuardrailContentFilter$ = GuardrailContentFilter$;
exports.GuardrailContentFilterConfidence = GuardrailContentFilterConfidence;
exports.GuardrailContentFilterStrength = GuardrailContentFilterStrength;
exports.GuardrailContentFilterType = GuardrailContentFilterType;
exports.GuardrailContentPolicyAction = GuardrailContentPolicyAction;
exports.GuardrailContentPolicyAssessment$ = GuardrailContentPolicyAssessment$;
exports.GuardrailContentQualifier = GuardrailContentQualifier;
exports.GuardrailContentSource = GuardrailContentSource;
exports.GuardrailContextualGroundingFilter$ = GuardrailContextualGroundingFilter$;
exports.GuardrailContextualGroundingFilterType = GuardrailContextualGroundingFilterType;
exports.GuardrailContextualGroundingPolicyAction = GuardrailContextualGroundingPolicyAction;
exports.GuardrailContextualGroundingPolicyAssessment$ = GuardrailContextualGroundingPolicyAssessment$;
exports.GuardrailConverseContentBlock$ = GuardrailConverseContentBlock$;
exports.GuardrailConverseContentQualifier = GuardrailConverseContentQualifier;
exports.GuardrailConverseImageBlock$ = GuardrailConverseImageBlock$;
exports.GuardrailConverseImageFormat = GuardrailConverseImageFormat;
exports.GuardrailConverseImageSource$ = GuardrailConverseImageSource$;
exports.GuardrailConverseTextBlock$ = GuardrailConverseTextBlock$;
exports.GuardrailCoverage$ = GuardrailCoverage$;
exports.GuardrailCustomWord$ = GuardrailCustomWord$;
exports.GuardrailImageBlock$ = GuardrailImageBlock$;
exports.GuardrailImageCoverage$ = GuardrailImageCoverage$;
exports.GuardrailImageFormat = GuardrailImageFormat;
exports.GuardrailImageSource$ = GuardrailImageSource$;
exports.GuardrailInvocationMetrics$ = GuardrailInvocationMetrics$;
exports.GuardrailManagedWord$ = GuardrailManagedWord$;
exports.GuardrailManagedWordType = GuardrailManagedWordType;
exports.GuardrailOrigin = GuardrailOrigin;
exports.GuardrailOutputContent$ = GuardrailOutputContent$;
exports.GuardrailOutputScope = GuardrailOutputScope;
exports.GuardrailOwnership = GuardrailOwnership;
exports.GuardrailPiiEntityFilter$ = GuardrailPiiEntityFilter$;
exports.GuardrailPiiEntityType = GuardrailPiiEntityType;
exports.GuardrailRegexFilter$ = GuardrailRegexFilter$;
exports.GuardrailSensitiveInformationPolicyAction = GuardrailSensitiveInformationPolicyAction;
exports.GuardrailSensitiveInformationPolicyAssessment$ = GuardrailSensitiveInformationPolicyAssessment$;
exports.GuardrailStreamConfiguration$ = GuardrailStreamConfiguration$;
exports.GuardrailStreamProcessingMode = GuardrailStreamProcessingMode;
exports.GuardrailTextBlock$ = GuardrailTextBlock$;
exports.GuardrailTextCharactersCoverage$ = GuardrailTextCharactersCoverage$;
exports.GuardrailTopic$ = GuardrailTopic$;
exports.GuardrailTopicPolicyAction = GuardrailTopicPolicyAction;
exports.GuardrailTopicPolicyAssessment$ = GuardrailTopicPolicyAssessment$;
exports.GuardrailTopicType = GuardrailTopicType;
exports.GuardrailTrace = GuardrailTrace;
exports.GuardrailTraceAssessment$ = GuardrailTraceAssessment$;
exports.GuardrailUsage$ = GuardrailUsage$;
exports.GuardrailWordPolicyAction = GuardrailWordPolicyAction;
exports.GuardrailWordPolicyAssessment$ = GuardrailWordPolicyAssessment$;
exports.ImageBlock$ = ImageBlock$;
exports.ImageBlockDelta$ = ImageBlockDelta$;
exports.ImageBlockStart$ = ImageBlockStart$;
exports.ImageFormat = ImageFormat;
exports.ImageSource$ = ImageSource$;
exports.InferenceConfiguration$ = InferenceConfiguration$;
exports.InternalServerException = InternalServerException;
exports.InternalServerException$ = InternalServerException$;
exports.InvokeGuardrailChecks$ = InvokeGuardrailChecks$;
exports.InvokeGuardrailChecksCommand = InvokeGuardrailChecksCommand;
exports.InvokeGuardrailChecksRequest$ = InvokeGuardrailChecksRequest$;
exports.InvokeGuardrailChecksResponse$ = InvokeGuardrailChecksResponse$;
exports.InvokeModel$ = InvokeModel$;
exports.InvokeModelCommand = InvokeModelCommand;
exports.InvokeModelRequest$ = InvokeModelRequest$;
exports.InvokeModelResponse$ = InvokeModelResponse$;
exports.InvokeModelTokensRequest$ = InvokeModelTokensRequest$;
exports.InvokeModelWithBidirectionalStream$ = InvokeModelWithBidirectionalStream$;
exports.InvokeModelWithBidirectionalStreamCommand = InvokeModelWithBidirectionalStreamCommand;
exports.InvokeModelWithBidirectionalStreamInput$ = InvokeModelWithBidirectionalStreamInput$;
exports.InvokeModelWithBidirectionalStreamOutput$ = InvokeModelWithBidirectionalStreamOutput$;
exports.InvokeModelWithBidirectionalStreamRequest$ = InvokeModelWithBidirectionalStreamRequest$;
exports.InvokeModelWithBidirectionalStreamResponse$ = InvokeModelWithBidirectionalStreamResponse$;
exports.InvokeModelWithResponseStream$ = InvokeModelWithResponseStream$;
exports.InvokeModelWithResponseStreamCommand = InvokeModelWithResponseStreamCommand;
exports.InvokeModelWithResponseStreamRequest$ = InvokeModelWithResponseStreamRequest$;
exports.InvokeModelWithResponseStreamResponse$ = InvokeModelWithResponseStreamResponse$;
exports.JsonSchemaDefinition$ = JsonSchemaDefinition$;
exports.ListAsyncInvokes$ = ListAsyncInvokes$;
exports.ListAsyncInvokesCommand = ListAsyncInvokesCommand;
exports.ListAsyncInvokesRequest$ = ListAsyncInvokesRequest$;
exports.ListAsyncInvokesResponse$ = ListAsyncInvokesResponse$;
exports.Message$ = Message$;
exports.MessageStartEvent$ = MessageStartEvent$;
exports.MessageStopEvent$ = MessageStopEvent$;
exports.ModelErrorException = ModelErrorException;
exports.ModelErrorException$ = ModelErrorException$;
exports.ModelNotReadyException = ModelNotReadyException;
exports.ModelNotReadyException$ = ModelNotReadyException$;
exports.ModelStreamErrorException = ModelStreamErrorException;
exports.ModelStreamErrorException$ = ModelStreamErrorException$;
exports.ModelTimeoutException = ModelTimeoutException;
exports.ModelTimeoutException$ = ModelTimeoutException$;
exports.OutputConfig$ = OutputConfig$;
exports.OutputFormat$ = OutputFormat$;
exports.OutputFormatStructure$ = OutputFormatStructure$;
exports.OutputFormatType = OutputFormatType;
exports.PayloadPart$ = PayloadPart$;
exports.PerformanceConfigLatency = PerformanceConfigLatency;
exports.PerformanceConfiguration$ = PerformanceConfiguration$;
exports.PromptRouterTrace$ = PromptRouterTrace$;
exports.PromptVariableValues$ = PromptVariableValues$;
exports.ReasoningContentBlock$ = ReasoningContentBlock$;
exports.ReasoningContentBlockDelta$ = ReasoningContentBlockDelta$;
exports.ReasoningTextBlock$ = ReasoningTextBlock$;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ResourceNotFoundException$ = ResourceNotFoundException$;
exports.ResponseStream$ = ResponseStream$;
exports.S3Location$ = S3Location$;
exports.SearchResultBlock$ = SearchResultBlock$;
exports.SearchResultContentBlock$ = SearchResultContentBlock$;
exports.SearchResultLocation$ = SearchResultLocation$;
exports.ServiceQuotaExceededException = ServiceQuotaExceededException;
exports.ServiceQuotaExceededException$ = ServiceQuotaExceededException$;
exports.ServiceTier$ = ServiceTier$;
exports.ServiceTierType = ServiceTierType;
exports.ServiceUnavailableException = ServiceUnavailableException;
exports.ServiceUnavailableException$ = ServiceUnavailableException$;
exports.SortAsyncInvocationBy = SortAsyncInvocationBy;
exports.SortOrder = SortOrder;
exports.SpecificToolChoice$ = SpecificToolChoice$;
exports.StartAsyncInvoke$ = StartAsyncInvoke$;
exports.StartAsyncInvokeCommand = StartAsyncInvokeCommand;
exports.StartAsyncInvokeRequest$ = StartAsyncInvokeRequest$;
exports.StartAsyncInvokeResponse$ = StartAsyncInvokeResponse$;
exports.StopReason = StopReason;
exports.SystemContentBlock$ = SystemContentBlock$;
exports.SystemTool$ = SystemTool$;
exports.Tag$ = Tag$;
exports.ThrottlingException = ThrottlingException;
exports.ThrottlingException$ = ThrottlingException$;
exports.TokenUsage$ = TokenUsage$;
exports.Tool$ = Tool$;
exports.ToolChoice$ = ToolChoice$;
exports.ToolConfiguration$ = ToolConfiguration$;
exports.ToolInputSchema$ = ToolInputSchema$;
exports.ToolResultBlock$ = ToolResultBlock$;
exports.ToolResultBlockDelta$ = ToolResultBlockDelta$;
exports.ToolResultBlockStart$ = ToolResultBlockStart$;
exports.ToolResultContentBlock$ = ToolResultContentBlock$;
exports.ToolResultStatus = ToolResultStatus;
exports.ToolSpecification$ = ToolSpecification$;
exports.ToolUseBlock$ = ToolUseBlock$;
exports.ToolUseBlockDelta$ = ToolUseBlockDelta$;
exports.ToolUseBlockStart$ = ToolUseBlockStart$;
exports.ToolUseType = ToolUseType;
exports.Trace = Trace;
exports.ValidationException = ValidationException;
exports.ValidationException$ = ValidationException$;
exports.VideoBlock$ = VideoBlock$;
exports.VideoFormat = VideoFormat;
exports.VideoSource$ = VideoSource$;
exports.WebLocation$ = WebLocation$;
exports.errorTypeRegistries = errorTypeRegistries;
exports.paginateListAsyncInvokes = paginateListAsyncInvokes;
