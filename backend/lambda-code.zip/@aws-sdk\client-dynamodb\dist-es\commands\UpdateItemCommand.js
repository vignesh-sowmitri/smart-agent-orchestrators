import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateItem$ } from "../schemas/schemas_0";
export class UpdateItemCommand extends command(_ep2, _mw0, "UpdateItem", UpdateItem$) {
}
