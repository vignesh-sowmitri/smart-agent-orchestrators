import { _ep2, _mw0, command } from "../commandBuilder";
import { DescribeTimeToLive$ } from "../schemas/schemas_0";
export class DescribeTimeToLiveCommand extends command(_ep2, _mw0, "DescribeTimeToLive", DescribeTimeToLive$) {
}
