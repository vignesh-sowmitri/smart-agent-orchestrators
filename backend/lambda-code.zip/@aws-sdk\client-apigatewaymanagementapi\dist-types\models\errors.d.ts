import type { ExceptionOptionType as __ExceptionOptionType } from "@smithy/core/client";
import { ApiGatewayManagementApiServiceException as __BaseException } from "./ApiGatewayManagementApiServiceException";
/**
 * <p>The caller is not authorized to invoke this operation.</p>
 * @public
 */
export declare class ForbiddenException extends __BaseException {
    readonly name: "ForbiddenException";
    readonly $fault: "client";
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<ForbiddenException, __BaseException>);
}
/**
 * <p>The connection with the provided id no longer exists.</p>
 * @public
 */
export declare class GoneException extends __BaseException {
    readonly name: "GoneException";
    readonly $fault: "client";
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<GoneException, __BaseException>);
}
/**
 * <p>The client is sending more than the allowed number of requests per unit of time or the WebSocket client side buffer is full.</p>
 * @public
 */
export declare class LimitExceededException extends __BaseException {
    readonly name: "LimitExceededException";
    readonly $fault: "client";
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<LimitExceededException, __BaseException>);
}
/**
 * <p>The data has exceeded the maximum size allowed.</p>
 * @public
 */
export declare class PayloadTooLargeException extends __BaseException {
    readonly name: "PayloadTooLargeException";
    readonly $fault: "client";
    Message?: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<PayloadTooLargeException, __BaseException>);
}
