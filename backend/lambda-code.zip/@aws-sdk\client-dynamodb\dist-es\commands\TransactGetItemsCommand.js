import { _ep11, _mw0, command } from "../commandBuilder";
import { TransactGetItems$ } from "../schemas/schemas_0";
export class TransactGetItemsCommand extends command(_ep11, _mw0, "TransactGetItems", TransactGetItems$) {
}
