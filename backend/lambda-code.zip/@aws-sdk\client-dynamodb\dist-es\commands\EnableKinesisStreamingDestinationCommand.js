import { _ep2, _mw0, command } from "../commandBuilder";
import { EnableKinesisStreamingDestination$ } from "../schemas/schemas_0";
export class EnableKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "EnableKinesisStreamingDestination", EnableKinesisStreamingDestination$) {
}
