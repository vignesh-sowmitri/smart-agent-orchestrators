import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteConnectionRequest } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteConnectionCommandInput extends DeleteConnectionRequest {}
export interface DeleteConnectionCommandOutput extends __MetadataBearer {}
declare const DeleteConnectionCommand_base: {
  new (
    input: DeleteConnectionCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DeleteConnectionCommandInput,
    DeleteConnectionCommandOutput,
    import("..").ApiGatewayManagementApiClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteConnectionCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DeleteConnectionCommandInput,
    DeleteConnectionCommandOutput,
    import("..").ApiGatewayManagementApiClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteConnectionCommand extends DeleteConnectionCommand_base {
  protected static __types: {
    api: {
      input: DeleteConnectionRequest;
      output: {};
    };
    sdk: {
      input: DeleteConnectionCommandInput;
      output: DeleteConnectionCommandOutput;
    };
  };
}
