export interface DeleteConnectionRequest {
  ConnectionId: string | undefined;
}
export interface GetConnectionRequest {
  ConnectionId: string | undefined;
}
export interface Identity {
  SourceIp: string | undefined;
  UserAgent: string | undefined;
}
export interface GetConnectionResponse {
  ConnectedAt?: Date | undefined;
  Identity?: Identity | undefined;
  LastActiveAt?: Date | undefined;
}
export interface PostToConnectionRequest {
  Data: Uint8Array | undefined;
  ConnectionId: string | undefined;
}
