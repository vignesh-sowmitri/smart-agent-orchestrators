import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DeleteItemInput, DeleteItemOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DeleteItemCommandInput extends DeleteItemInput {}
export interface DeleteItemCommandOutput
  extends DeleteItemOutput,
    __MetadataBearer {}
declare const DeleteItemCommand_base: {
  new (
    input: DeleteItemCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DeleteItemCommandInput,
    DeleteItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DeleteItemCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DeleteItemCommandInput,
    DeleteItemCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DeleteItemCommand extends DeleteItemCommand_base {
  protected static __types: {
    api: {
      input: DeleteItemInput;
      output: DeleteItemOutput;
    };
    sdk: {
      input: DeleteItemCommandInput;
      output: DeleteItemCommandOutput;
    };
  };
}
