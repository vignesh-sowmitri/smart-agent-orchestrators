import { _ep0, _mw0, command } from "../commandBuilder";
import { DeleteConnection$ } from "../schemas/schemas_0";
export class DeleteConnectionCommand extends command(_ep0, _mw0, "DeleteConnection", DeleteConnection$) {
}
