import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ScanInput, ScanOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ScanCommandInput extends ScanInput {}
export interface ScanCommandOutput extends ScanOutput, __MetadataBearer {}
declare const ScanCommand_base: {
  new (input: ScanCommandInput): import("@smithy/core/client").CommandImpl<
    ScanCommandInput,
    ScanCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (input: ScanCommandInput): import("@smithy/core/client").CommandImpl<
    ScanCommandInput,
    ScanCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ScanCommand extends ScanCommand_base {
  protected static __types: {
    api: {
      input: ScanInput;
      output: ScanOutput;
    };
    sdk: {
      input: ScanCommandInput;
      output: ScanCommandOutput;
    };
  };
}
