import { makeBuilder } from "@smithy/core/client";
import { getEndpointPlugin } from "@smithy/core/endpoints";
import { commonParams } from "./endpoint/EndpointParameters";
export const command = makeBuilder(commonParams, "DynamoDB_20120810", "DynamoDBClient", getEndpointPlugin);
export const _ep0 = {};
export const _ep1 = {
    ResourceArnList: { type: "operationContextParams", get: (input) => Object.keys(input?.RequestItems ?? {}) },
};
export const _ep2 = {
    ResourceArn: { type: "contextParams", name: "TableName" },
};
export const _ep3 = {
    ResourceArn: { type: "contextParams", name: "GlobalTableName" },
};
export const _ep4 = {
    ResourceArn: { type: "contextParams", name: "BackupArn" },
};
export const _ep5 = {
    ResourceArn: { type: "contextParams", name: "ResourceArn" },
};
export const _ep6 = {
    ResourceArn: { type: "contextParams", name: "ExportArn" },
};
export const _ep7 = {
    ResourceArn: { type: "contextParams", name: "ImportArn" },
};
export const _ep8 = {
    ResourceArn: { type: "contextParams", name: "TableArn" },
};
export const _ep9 = {
    ResourceArn: { type: "operationContextParams", get: (input) => input?.TableCreationParameters?.TableName },
};
export const _ep10 = {
    ResourceArn: { type: "contextParams", name: "TargetTableName" },
};
export const _ep11 = {
    ResourceArnList: { type: "operationContextParams", get: (input) => input?.TransactItems?.map((obj) => obj?.Get?.TableName) },
};
export const _ep12 = {
    ResourceArnList: { type: "operationContextParams", get: (input) => input?.TransactItems?.map((obj) => [obj?.ConditionCheck?.TableName, obj?.Put?.TableName, obj?.Delete?.TableName, obj?.Update?.TableName].filter((i) => i)).flat() },
};
export const _mw0 = (Command, cs, config, o) => [];
