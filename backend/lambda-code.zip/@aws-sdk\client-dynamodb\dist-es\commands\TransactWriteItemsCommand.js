import { _ep12, _mw0, command } from "../commandBuilder";
import { TransactWriteItems$ } from "../schemas/schemas_0";
export class TransactWriteItemsCommand extends command(_ep12, _mw0, "TransactWriteItems", TransactWriteItems$) {
}
