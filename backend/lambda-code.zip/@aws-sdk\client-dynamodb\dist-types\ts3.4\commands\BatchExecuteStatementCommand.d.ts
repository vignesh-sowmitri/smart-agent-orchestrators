import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  BatchExecuteStatementInput,
  BatchExecuteStatementOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface BatchExecuteStatementCommandInput
  extends BatchExecuteStatementInput {}
export interface BatchExecuteStatementCommandOutput
  extends BatchExecuteStatementOutput,
    __MetadataBearer {}
declare const BatchExecuteStatementCommand_base: {
  new (
    input: BatchExecuteStatementCommandInput
  ): import("@smithy/core/client").CommandImpl<
    BatchExecuteStatementCommandInput,
    BatchExecuteStatementCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: BatchExecuteStatementCommandInput
  ): import("@smithy/core/client").CommandImpl<
    BatchExecuteStatementCommandInput,
    BatchExecuteStatementCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class BatchExecuteStatementCommand extends BatchExecuteStatementCommand_base {
  protected static __types: {
    api: {
      input: BatchExecuteStatementInput;
      output: BatchExecuteStatementOutput;
    };
    sdk: {
      input: BatchExecuteStatementCommandInput;
      output: BatchExecuteStatementCommandOutput;
    };
  };
}
