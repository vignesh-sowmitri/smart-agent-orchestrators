import { _ep0, _mw0, command } from "../commandBuilder";
import { ExecuteTransaction$ } from "../schemas/schemas_0";
export class ExecuteTransactionCommand extends command(_ep0, _mw0, "ExecuteTransaction", ExecuteTransaction$) {
}
