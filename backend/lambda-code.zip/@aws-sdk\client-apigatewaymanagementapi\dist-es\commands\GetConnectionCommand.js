import { _ep0, _mw0, command } from "../commandBuilder";
import { GetConnection$ } from "../schemas/schemas_0";
export class GetConnectionCommand extends command(_ep0, _mw0, "GetConnection", GetConnection$) {
}
