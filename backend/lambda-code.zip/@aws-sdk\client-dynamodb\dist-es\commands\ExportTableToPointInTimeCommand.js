import { _ep8, _mw0, command } from "../commandBuilder";
import { ExportTableToPointInTime$ } from "../schemas/schemas_0";
export class ExportTableToPointInTimeCommand extends command(_ep8, _mw0, "ExportTableToPointInTime", ExportTableToPointInTime$) {
}
