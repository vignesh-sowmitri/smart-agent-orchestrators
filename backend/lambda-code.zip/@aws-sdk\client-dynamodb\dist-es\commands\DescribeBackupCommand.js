import { _ep4, _mw0, command } from "../commandBuilder";
import { DescribeBackup$ } from "../schemas/schemas_0";
export class DescribeBackupCommand extends command(_ep4, _mw0, "DescribeBackup", DescribeBackup$) {
}
