import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  GetConnectionRequest,
  GetConnectionResponse,
} from "../models/models_0";
export { __MetadataBearer };
export interface GetConnectionCommandInput extends GetConnectionRequest {}
export interface GetConnectionCommandOutput
  extends GetConnectionResponse,
    __MetadataBearer {}
declare const GetConnectionCommand_base: {
  new (
    input: GetConnectionCommandInput
  ): import("@smithy/core/client").CommandImpl<
    GetConnectionCommandInput,
    GetConnectionCommandOutput,
    import("..").ApiGatewayManagementApiClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetConnectionCommandInput
  ): import("@smithy/core/client").CommandImpl<
    GetConnectionCommandInput,
    GetConnectionCommandOutput,
    import("..").ApiGatewayManagementApiClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetConnectionCommand extends GetConnectionCommand_base {
  protected static __types: {
    api: {
      input: GetConnectionRequest;
      output: GetConnectionResponse;
    };
    sdk: {
      input: GetConnectionCommandInput;
      output: GetConnectionCommandOutput;
    };
  };
}
