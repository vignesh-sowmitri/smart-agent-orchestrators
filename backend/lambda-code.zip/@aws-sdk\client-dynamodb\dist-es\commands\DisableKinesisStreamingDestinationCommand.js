import { _ep2, _mw0, command } from "../commandBuilder";
import { DisableKinesisStreamingDestination$ } from "../schemas/schemas_0";
export class DisableKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "DisableKinesisStreamingDestination", DisableKinesisStreamingDestination$) {
}
