import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeBackupInput, DescribeBackupOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeBackupCommandInput extends DescribeBackupInput {}
export interface DescribeBackupCommandOutput
  extends DescribeBackupOutput,
    __MetadataBearer {}
declare const DescribeBackupCommand_base: {
  new (
    input: DescribeBackupCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DescribeBackupCommandInput,
    DescribeBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeBackupCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DescribeBackupCommandInput,
    DescribeBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeBackupCommand extends DescribeBackupCommand_base {
  protected static __types: {
    api: {
      input: DescribeBackupInput;
      output: DescribeBackupOutput;
    };
    sdk: {
      input: DescribeBackupCommandInput;
      output: DescribeBackupCommandOutput;
    };
  };
}
