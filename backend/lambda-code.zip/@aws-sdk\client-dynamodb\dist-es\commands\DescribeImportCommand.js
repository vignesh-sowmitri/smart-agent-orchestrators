import { _ep7, _mw0, command } from "../commandBuilder";
import { DescribeImport$ } from "../schemas/schemas_0";
export class DescribeImportCommand extends command(_ep7, _mw0, "DescribeImport", DescribeImport$) {
}
