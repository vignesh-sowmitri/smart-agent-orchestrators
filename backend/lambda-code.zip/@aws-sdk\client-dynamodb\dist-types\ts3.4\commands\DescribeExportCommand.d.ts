import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeExportInput, DescribeExportOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeExportCommandInput extends DescribeExportInput {}
export interface DescribeExportCommandOutput
  extends DescribeExportOutput,
    __MetadataBearer {}
declare const DescribeExportCommand_base: {
  new (
    input: DescribeExportCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DescribeExportCommandInput,
    DescribeExportCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeExportCommandInput
  ): import("@smithy/core/client").CommandImpl<
    DescribeExportCommandInput,
    DescribeExportCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeExportCommand extends DescribeExportCommand_base {
  protected static __types: {
    api: {
      input: DescribeExportInput;
      output: DescribeExportOutput;
    };
    sdk: {
      input: DescribeExportCommandInput;
      output: DescribeExportCommandOutput;
    };
  };
}
